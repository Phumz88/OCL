<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Best Pick  Loan  (PTY) Ltd">
    <meta name="keywords" content="Best Pick  Loan  (PTY) Ltd,Loan company in south africa, Education loan, quick Education loan, get loan,contact loan company">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Education Loan| Best Pick  Loan  (PTY) Ltd </title>
    <link rel="shortcut icon" href="./img/choose/choose-5.png" type="image/x-icon">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700;900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<body>
    <!-- Page Preloder -->
    <link rel="stylesheet" href="./plugins.css" type="text/css">
<link rel="stylesheet" href="./pluinstyle.css" type="text/css">
 <!-- theme core css -->
 

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@icon/themify-icons@1.0.1-alpha.3/themify-icons.min.css">

     <!-- Libraries Stylesheet -->
     <link rel="stylesheet" href="./style2/lib/animate/animate.min.css"/>
        <link href="./style2/lib/lightbox/css/lightbox.min.css" rel="stylesheet">
        <link href="./style2/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

        <!-- Customized Bootstrap Stylesheet -->
        <link href="./style2/css/bootstrap.min.css" rel="stylesheet">
        <!-- Template Stylesheet -->
        <link href="./style2/css/style.css" rel="stylesheet">

        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

        <!-- Icon Font Stylesheet -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    
    <!--Animation--> 
    <link href="./css/aos.css" rel="stylesheet">
    <!--Animation Script--> 
<script src="./js/aos.js"></script>
        <script>
        AOS.init();
        </script>


<!--
<div id="preloder">
    <div class="loader"></div>
</div>-->

  <!-- Spinner Start -->
  <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

<style>
.bg-gradient-pink{
    background: #CF327B;
 
}
</style>

<!-- Offcanvas Menu Begin -->
<div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel"  style="z-index:111111111 !important;">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasRightLabel"> <h1 class="text-primary mb-0 ms-2"><small> <img src="./img/logo.png" alt="" srcset=""> </small></h1></h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
  <a href="./app.php?a23c66w8-329b-4e67-9169-c5f5899dee4f" class="btn btn-primary rounded-pill py-2 px-4 ms-3 flex-shrink-0 mb-3"> Get Loan <i class="fa fa-arrow-right"></i> </a>
<ul class="list-style1 list-unstyled mb-0 ps-0">
    <li><a href="./index.php">Home  <i class="ti ti-arrow-right"></i></li>
    <li><a href="./personal-loan.php">Personal Loan <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./business-loan.php">Business Loan <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./home-loan.php">Home Loan <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./education-loan.php">Education Loan <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./carloan.php">Auto Loan <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./insurance.php">Insurance <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./about.php">About us  <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./testmonial.php">Testimonials  <i class="ti ti-arrow-right"></i></a></li>
     <li><a href="./contact.php">Contact us  <i class="ti ti-arrow-right"></i></a></li>
  
   
</ul>

                                    
  </div>
</div>
        <!-- Topbar Start -->
        <div class="container-fluid topbar px-0 px-lg-4 bg-light py-2 d-block">
            <div class="container">
                <div class="row gx-0 align-items-center">
                    <div class="col-lg-8 text-center text-lg-start mb-lg-0">
                        <div class="d-flex">
                            <div class="border-end border-dark pe-3">
                                <a href="#" class="text-muted small"><i class="bi bi-whatsapp text-primary me-2"></i> 0736505209, +27145470012</a>
                            </div>
                            <div class="ps-3">
                                <a href="mailto:loan@bestpickloans.co.za" class="text-muted small"><i class="fas fa-envelope text-primary me-2"></i>loan@bestpickloans.co.za</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 text-center text-lg-end">
                        <div class="d-flex justify-content-end">
                            <div class="d-flex border-end border-primary pe-3 d-none d-lg-block">
                                <a class="btn p-0 text-dark me-3" href="#"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn p-0 text-dark me-3" href="#"><i class="fab fa-twitter"></i></a>
                                <a class="btn p-0 text-dark me-3" href="#"><i class="fab fa-instagram"></i></a>
                                <a class="btn p-0 text-dark me-0" href="#"><i class="fab fa-linkedin-in"></i></a>
                            </div>
                            <div class="dropdown ms-3">
                                <a href="#" class="dropdown-toggle text-dark" data-bs-toggle="dropdown"><small><i class="fas fa-globe-europe text-primary me-2"></i> English</small></a>
                                <div class="dropdown-menu rounded">
                                    <a href="#" class="dropdown-item">English</a>
                                    <a href="#" class="dropdown-item">Bangla</a>
                                    <a href="#" class="dropdown-item">French</a>
                                    <a href="#" class="dropdown-item">Spanish</a>
                                    <a href="#" class="dropdown-item">Arabic</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Topbar End -->


      <!-- Navbar & Hero Start -->
     
<div class="container-fluid nav-bar px-0 px-lg-4 py-lg-0">
            <div class="">
                <nav class="navbar navbar-expand-lg navbar-light"> 
                    <a href="#" class="navbar-brand p-0">
                        <h3 class="text-dark mb-0 ms-2"><i class="fab fas-seadling me-2"></i><small><img src="./img/logo.png" alt="" srcset="" class="w-100"></small></h3>
                        <!-- <img src="img/logo.png" alt="Logo"> -->
                    </a>
                    <button class="navbar-toggler me-2" type="button" data-bs-toggle="offcanvas" href="#offcanvasRight" role="button" aria-controls="offcanvasRight">
                        <span class="fa fa-bars"></span>
                    </button>
                    <div class="navbar-collapse collapse" id="navbarCollapse" style="">
                        <div class="navbar-nav mx-0 mx-lg-auto">
                            <a href="./index.php" class="nav-item nav-link active">Home</a>
                            <a href="./about.php" class="nav-item nav-link">About</a>
                         
                        
                            <div class="nav-item dropdown">
                                <a href="#" class="nav-link" data-bs-toggle="dropdown">
                                    <span class="dropdown-toggle">Loan Services</span>
                                </a>
                                <div class="dropdown-menu">
                                    <a href="./personal-loan.php" class="dropdown-item">Personal Loans</a>
                                    <a href="./business-loan.php" class="dropdown-item">Business Loans</a>
                                    <a href="./home-loan.php" class="dropdown-item">Home Loan</a>
                                    <a href="./education-loan.php" class="dropdown-item">Education Loan</a>
                                    <a href="./carloan.php" class="dropdown-item">Auto Loan</a>
                                </div>
                            </div>
                            <a href="./insurance.php" class="nav-item nav-link">Insurance</a>
                            <a href="./testmonial.php" class="nav-item nav-link">Testimonial</a>
                            <a href="./contact.php" class="nav-item nav-link">Contact us</a>
                            <a href="./app.php?a23c66w8-329b-4e67-9169-c5f5899dee4f" class="btn btn-primary rounded-pill py-2 px-4 ms-3 flex-shrink-0"> Get Loan <i class="fa fa-arrow-right"></i> </a>
                           
                        </div>
                    </div>
                    <div class="d-none d-xl-flex flex-shrink-0 ps-4">
                        <a href="#" class="btn btn-primary btn-lg-square rounded-circle position-relative wow tada" data-wow-delay=".9s" style="visibility: visible; animation-delay: 0.9s; animation-name: tada;">
                            <i class="bi bi-whatsapp fa-2x"></i>
                            <div class="position-absolute" style="top: 7px; right: 12px;">
                               <!-- <span><i class="fa fa-comment-dots text-secondary"></i></span>-->
                            </div>
                        </a>
                        <div class="d-flex flex-column ms-3">
                            <span class="text-primary fw-bolder">Whatsapp support</span>
                            <a href="tel: 0736505209"><span class="text-dark"> 0736505209</span></a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>

     
        <!-- Navbar & Hero End -->

        <!-- Modal Search Start -->
        <div class="modal fade" id="searchModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content rounded-0">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Search by keyword</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body d-flex align-items-center bg-primary">
                        <div class="input-group w-75 mx-auto d-flex">
                            <input type="search" class="form-control p-3" placeholder="keywords" aria-describedby="search-icon-1">
                            <span id="search-icon-1" class="btn bg-light border nput-group-text p-3"><i class="fa fa-search"></i></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal Search End -->

    <!-- Header Section End -->

    <section class="page-title-section  bg-img cover-background" data-overlay-dark="55"
        data-background="https://images.unsplash.com/photo-1599687351724-dfa3c4ff81b1?q=80&w=1740&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" style="background-image: url(https://images.unsplash.com/photo-1599687351724-dfa3c4ff81b1?q=80&w=1740&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D);">
        <div class="container">

            <div class="row">
                <div class="col-md-12">
                    <h1>Education Loan</h1>
                    <ul class="ps-0">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="./app.php?a23c66f8-329b-4e77-9169-c5f5899dee7f">Apply for loan</a></li>
                    </ul>
                </div>
            </div>

        </div>
    </section>


    <section>
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 order-2 order-lg-1">
                        <div class="sidebar pe-lg-1-9">
                            <div class="loan-type mb-4">
                                <ul class="list-unstyled m-0">
                                    <li class="active"><a href="./business-loan.php">Business Loan</a></li>
                                    <li><a href="./carloan.php">Car Loan</a></li>
                                    <li><a href="./personal-loan.php">Personal Loan</a></li>
                                    <li><a href="./home-loan.php">Home Loan</a></li>
                                </ul>
                            </div>
                            <div class="bg-secondary rounded mb-4">
                                <div class="position-relative z-index-9 text-center py-5">
                                    <i class="fas fa-headset text-white mb-4 display-14"></i>
                                    <h5 class="text-white mb-4">Have Any Questions?</h5>
                                    <div class="separator-line-horrizontal-full bg-white opacity4 mb-4"></div>
                                    <ul class="text-center list-unstyled mb-0">
                                        <li class="text-white mb-2"><i class="fa fa-phone small text-white me-2"></i><a href="#!" class="text-white">Whatsapp: 0736505209, 0719443402</a></li>
                                        <li class="text-white"><i class="fa fa-envelope-open small text-white me-2"></i><a href="mailto:loan@bestpickloans.co.za" class="text-white">loan@bestpickloans.co.za</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="mb-4">
                                <a href="./contact.php" class="butn w-100">Reach us</a>
                            </div>
                            
                        </div>
                    </div>
                    <div class="col-lg-8 order-1 order-lg-2 mb-1-9 mb-lg-0">
                        <div>
                            <div class="mb-4">
                                <img src="https://images.unsplash.com/photo-1523050854058-8df90110c9f1?q=80&w=1740&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" class="rounded" alt="...">
                            </div>
                            <h2 class="mb-3"> Invest in Your Future with Our Student Loans! 🎓</h2>
                            <p class="mb-4 mb-lg-5">Finance your part- or full-time studies with our student loan. Embarking on your educational journey is an investment in yourself and your future. At Best Pick  Loan  , we're here to ensure that nothing stands in the way of you achieving your academic dreams. With our student loans, you can focus on your studies while we take care of the finances. Get the skills you need with up to R250 0000 credit at a discounted interest rate.  <a href="./app.php?a23c66f8-329b-4e77-9169-c5f5899dee7f"> <U>Apply Online</U> today and enjoy an affordable interest rate. </a>  </p>
 <p>

 <h3 class="h5 mb-3">Go further with a Best Pick  Loan  (PTY) Ltd Student Loan</h3>
                            <p class="mb-4 mb-lg-5"> Get an education loan of up to R500 000 to pay for tuition and educational expenses at any South African-registered institution. An Best Pick  Loan  (PTY) Ltd Student Loan can be used for tuition fees, accommodation, study material and more. Reach Your Potential While Enjoying the Benefits of a Personalised Interest Rate. <br><a href="terms.php" class="fw-bolder">Terms & Conditions</a> apply.</p>
 </p>
                            
                        
                        </div>
                    </div>
                </div>

               <div class="row mb-1-9 mb-lg-5 justify-content-center py-5">
                              <div class="col-10">
                              <h4>Why Choose Us for Your Student Loan?</h4>
  <ul> 

<li class="nav-link text-dark">📘 Affordable Financing: Don't let tuition fees hold you back. Our student loans offer competitive rates and flexible repayment options, making higher education more accessible than ever. </li>
<li class="nav-link text-dark">📘 No More Financial Stress: Say goodbye to sleepless nights worrying about how to pay for your education. Our straightforward application process and quick approval mean you can focus on what truly matters – your studies. </li>
<li class="nav-link text-dark"> 📘 Support Every Step of the Way: From application to graduation, our dedicated team is here to support you. Whether you have questions about your loan or need guidance on financial planning, we're just a call or click away</li>
<li class="nav-link text-dark"> 📘 Customized Solutions: We understand that every student's financial situation is unique. That's why we offer personalized loan solutions tailored to your needs, ensuring that you get the support you need, exactly when you need it.</li>
<li class="nav-link text-dark">📘 Building Your Credit: Responsible borrowing shouldn't be a barrier to your future financial goals. With our student loans, you'll have the opportunity to build a positive credit history, setting you up for success long after graduation. </li>
</ul>
                              </div>
                                <div class="col-sm-6 col-md-4 col-xl-4 mb-4 mb-md-0">
                                    <div class="card card-style4">
                                        <div class="card-body p-3 p-xl-4">
                                            <div class="media align-items-center">
                                                <i class="fas fa-hand-holding-usd text-primary display-20 display-xl-16"></i>
                                                <div class="media-body ms-3">
                                                    <h3 class="h6 mb-0 text-secondary">Calculate your instalment​</h3>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-6 col-md-4 col-xl-4 mb-4 mb-md-0">
                                    <div class="card card-style4">
                                        <div class="card-body p-3 p-xl-4">
                                            <div class="media align-items-center">
                                                <i class="fas fa-donate text-primary mb-0 display-20 display-xl-16"></i>
                                                <div class="media-body ms-3">
                                                    <h3 class="h6 mb-0 text-secondary"> <a href=""> Submit your application</a></h3>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div class="col-sm-6 col-md-4 col-xl-4">
                                    <div class="card card-style4">
                                        <div class="card-body p-3 p-xl-4">
                                            <div class="media align-items-center">
                                                <i class="fas fa-home text-primary display-20 display-xl-16"></i>
                                                <div class="media-body ms-3">
                                                    <h3 class="h6 mb-0 text-secondary">
Manage your Student loan​</h3>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-10 col-xl-12 col-lg-12 col-sm-10 mt-4">

                                <div class="row mb-2-9 mt-n4">
                                <div class="col-xl-6 pe-xl-5 order-2 order-xl-1 mt-4">
                                    <h4 class="h5 mb-3">Eligibility Criteria</h4>
                                    <p> you can apply for this loan if you are;</p>
                                    <ul class="list-style2 list-unstyled mb-0">
                                        <li class="mb-2">Are 18 years and older</li>
                                        <li class="mb-2">Have a valid National ID or driver’s license</li>
                                        <li class="mb-2">Have a bank account</li>
                                        <li>Are employed and earn R8,000 or more per months</li>
                                    </ul>
                                </div>
                                <div class="col-xl-6 order-1 order-xl-2 mt-4">
                                    <img src=" https://images.unsplash.com/photo-1599687351724-dfa3c4ff81b1?q=80&w=1740&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" class="rounded" alt="...">
                                </div>
                            </div>
                                </div>

                                <div class="col-md-10 col-xl-12 col-lg-12 col-sm-10">
                                <div class="row mb-2-9 mt-n4">
                                <div class="col-xl-6 mt-4">
                                    <img src="https://images.unsplash.com/photo-1660798027105-5da8ad164e27?q=80&w=1664&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" class="rounded" alt="...">
                                </div>
                                <div class="col-xl-6 ps-xl-5 mt-4">
                                    <h3 class="h5 mb-3">Documents Required</h3>
                                    <p>Getting a loan from Best Pick  Loan   requires the following documents;</p>
                                    <ul class="list-style2 list-unstyled mb-0">
                                        <li class="mb-2">Unique Identity Number</li>
                                        <li class="mb-2">Proof of Identity</li>
                                        <li class="mb-2">Lastest 2-3 months Bank statements</li>
                                        <li>Current address proof (optional)</li>
                                    </ul>
                                </div>
                            </div>
                                </div>

                            </div>

            </div>
        </section>



    <!-- Call Section Begin -->
    <section class="call spad set-bg" data-setbg="img/call-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-6">
                    <div class="call__text">
                        <div class="section-title">
                            <h2>Request A Call Back</h2>
                            <p>Posters had been a very beneficial marketing tool because it had paved to deliver an
                                effective message that conveyed customer’s attention.</p>
                        </div>
                        <a href="#">Contact Us</a>
                    </div>
                </div>
                <div class="col-lg-6 offset-lg-1 col-md-6">
                    <form action="#" class="call__form">
                        <div class="row">
                            <div class="col-lg-6">
                                <input type="text" placeholder="Name">
                            </div>
                            <div class="col-lg-6">
                                <input type="text" placeholder="Email">
                            </div>
                            <div class="col-lg-6">
                                <input type="text" placeholder="Phone">
                            </div>
                            <div class="col-lg-6">
                                <select>
                                    <option value="">Choose Our Services</option>
                                </select>
                            </div>
                        </div>
                        <button type="submit" class="site-btn">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- Call Section End -->

    <!-- Footer Section Begin -->
    <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/6738e5ff2480f5b4f59f10fd/1icr44s5a';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

<script>
        // JavaScript to hide the preloader and show the main content
        window.addEventListener('load', function() {
            document.getElementById('preloader').style.display = 'none';
            document.getElementById('main-content').style.display = 'block';
        });
      
    </script>

<script>
    var TxtType = function(el, toRotate, period) {
	this.toRotate = toRotate;
	this.el = el;
	this.loopNum = 0;
	this.period = parseInt(period, 10) || 2000;
	this.txt = '';
	this.tick();
	this.isDeleting = false;
};

TxtType.prototype.tick = function() {
	var i = this.loopNum % this.toRotate.length;
	var fullTxt = this.toRotate[i];

	if (this.isDeleting) {
		this.txt = fullTxt.substring(0, this.txt.length - 1);
	} else {
		this.txt = fullTxt.substring(0, this.txt.length + 1);
	}

	this.el.innerHTML = '<span class="wrap">'+this.txt+'</span>';

	var that = this;
	var delta = 200 - Math.random() * 100;

	if (this.isDeleting) { delta /= 2; }

	if (!this.isDeleting && this.txt === fullTxt) {
		delta = this.period;
		this.isDeleting = true;
	} else if (this.isDeleting && this.txt === '') {
		this.isDeleting = false;
		this.loopNum++;
		delta = 500;
	}

	setTimeout(function() {
		that.tick();
	}, delta);
};

window.onload = function() {
	var elements = document.getElementsByClassName('typewrite');
	for (var i=0; i<elements.length; i++) {
		var toRotate = elements[i].getAttribute('data-type');
		var period = elements[i].getAttribute('data-period');
		if (toRotate) {
			new TxtType(elements[i], JSON.parse(toRotate), period);
		}
	}
	// INJECT CSS
	var css = document.createElement("style");
	css.type = "text/css";
	css.innerHTML = ".typewrite > .wrap { border-right: 0.08em solid transparent}";
	document.body.appendChild(css);
};
</script>

<section>
            <div class="container">
                <div class="row justify-content-center">

                    <div class="col-lg-9">

                        <div class="position-relative elements-block">

                            <div class="inner-title">
                                <div class="main-title title-left mb-0">Frequently Asked Questions
                                    <span class="line-left"></span>
                                </div>
                            </div>

                            <div id="accordion" class="accordion-style">
                                <div class="card">
                                    <div class="card-header" id="headingOne">
                                        <h5 class="mb-0">
                                            <button class="btn btn-link" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">How do I apply for a loan at Best Pick  Loan  (PTY) Ltd ?</button>
                                        </h5>
                                    </div>
                                    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-bs-parent="#accordion">
                                        <div class="card-body position-relative">
                                        You can apply for an Best Pick  Loan  (PTY) Ltd by clicking here or you can call us at loan@bestpickloans.co.za
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingTwo">
                                        <h5 class="mb-0">
                                            <button class="btn btn-link collapsed" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">How do I pay my monthly loan instalment?</button>
                                        </h5>
                                    </div>
                                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-bs-parent="#accordion">
                                        <div class="card-body position-relative">
                                        Your monthly loan instalment will be automatically debited from your bank account on a date you selected at time of application.
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingThree">
                                        <h5 class="mb-0">
                                            <button class="btn btn-link collapsed" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">Can I apply and be offered a loan if I have a Bad Credit Profile?</button>
                                        </h5>
                                    </div>
                                    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-bs-parent="#accordion">
                                        <div class="card-body position-relative">
                                        Whether you are Blacklisted,Debt Review or your Credit Score is very low, you can apply for a loan. At Best Pick  Loan   Service Loan company, we help you removed blacklisted and increase credit score.
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingFour">
                                        <h5 class="mb-0">
                                            <button class="btn btn-link collapsed" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">Do I need to pay upfront fee before getting a Loan ?</button>
                                        </h5>
                                    </div>
                                    <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-bs-parent="#accordion">
                                        <div class="card-body position-relative">
                                        Best Pick  Loan  (PTY) Ltd do not charge client with good credit profile. However, you only make payment for upfront fee payment if your a having low credit score, blacklisted or Debt review. This fee is also refunded when you make payment on our last instalment.
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingFive">
                                        <h5 class="mb-0">
                                            <button class="btn btn-link collapsed" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">Can I apply for a loan outside South Africa?</button>
                                        </h5>
                                    </div>
                                    <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-bs-parent="#accordion">
                                        <div class="card-body position-relative">
                                        Best Pick  Loan  (PTY) Ltd  application process is online-based. Whether you reside in South Africaor any part of the world. Best Pick  Loan  (PTY) Ltd company accept clients from all part of the world. So long you have all valid required documents.
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="copy-element"><a class="copy-clipboard" data-clipboard-target="#section">Copy</a></div>
                           

                            <div id="copy-code" class="mfp-hide white-popup-block popup-copy">
                                <div class="copy-element"><a class="copy-clipboard" data-clipboard-target="#section">copy</a></div>
                                <pre id="section" class=" language-html"><code class=" language-html">
<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>accordion<span class="token punctuation">"</span></span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>accordion-style<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-header<span class="token punctuation">"</span></span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingOne<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>h5</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>mb-0<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>button</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>btn btn-link<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-toggle</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-target</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#collapseOne<span class="token punctuation">"</span></span> <span class="token attr-name">aria-expanded</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>true<span class="token punctuation">"</span></span> <span class="token attr-name">aria-controls</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseOne<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>How quick will my credit be subsidized?<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>button</span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>h5</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseOne<span class="token punctuation">"</span></span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse show<span class="token punctuation">"</span></span> <span class="token attr-name">aria-labelledby</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingOne<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-parent</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#accordion<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-body position-relative<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised.
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-header<span class="token punctuation">"</span></span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingTwo<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>h5</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>mb-0<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>button</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>btn btn-link collapsed<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-toggle</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-target</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#collapseTwo<span class="token punctuation">"</span></span> <span class="token attr-name">aria-expanded</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>false<span class="token punctuation">"</span></span> <span class="token attr-name">aria-controls</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseTwo<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>What is outsourced financial support?<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>button</span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>h5</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseTwo<span class="token punctuation">"</span></span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">aria-labelledby</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingTwo<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-parent</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#accordion<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-body position-relative<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-header<span class="token punctuation">"</span></span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingThree<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>h5</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>mb-0<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>button</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>btn btn-link collapsed<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-toggle</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-target</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#collapseThree<span class="token punctuation">"</span></span> <span class="token attr-name">aria-expanded</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>false<span class="token punctuation">"</span></span> <span class="token attr-name">aria-controls</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseThree<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>How long is an affirmed financing cost and credit offer substantial?<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>button</span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>h5</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseThree<span class="token punctuation">"</span></span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">aria-labelledby</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingThree<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-parent</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#accordion<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-body position-relative<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-header<span class="token punctuation">"</span></span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingFour<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>h5</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>mb-0<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>button</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>btn btn-link collapsed<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-toggle</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-target</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#collapseFour<span class="token punctuation">"</span></span> <span class="token attr-name">aria-expanded</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>false<span class="token punctuation">"</span></span> <span class="token attr-name">aria-controls</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseFour<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>What sorts of commercial enterprise financing do you offer?<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>button</span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>h5</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseFour<span class="token punctuation">"</span></span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">aria-labelledby</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingFour<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-parent</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#accordion<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-body position-relative<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-header<span class="token punctuation">"</span></span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingFive<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>h5</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>mb-0<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>button</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>btn btn-link collapsed<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-toggle</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-target</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#collapseFive<span class="token punctuation">"</span></span> <span class="token attr-name">aria-expanded</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>false<span class="token punctuation">"</span></span> <span class="token attr-name">aria-controls</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseFive<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>How might I roll out an improvement to my application?<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>button</span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>h5</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseFive<span class="token punctuation">"</span></span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">aria-labelledby</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingFive<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-parent</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#accordion<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-body position-relative<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, Making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable.
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
                    </code></pre>
                            </div>

                        </div>

                    </div>

                </div>
            </div>
        </section>



   <!-- Footer Start -->
   <div class="container-fluid footer py-5 wow fadeIn" data-wow-delay="0.2s" style="background: #151533;">
            <div class="container py-5">
                <div class="row g-5">
                    <div class="col-xl-9">
                        <div class="mb-5">
                            <div class="row g-4">
                                <div class="col-md-6 col-lg-6 col-xl-5">
                                    <div class="footer-item">
                                        <a href="index.php" class="p-0">
                                            <h3 class="text-white"><img src="./img/logo.png" /> </h3>
                                            <!-- <img src="img/logo.png" alt="Logo"> -->
                                        </a>
                                        <p class="text-white mb-4">Best Pick  Loan (Pty)is a nationwide brokerage with over years experience in the credit industry that helps clients all over South Africa to obtain Loans.</p>
                                        <div class="footer-btn d-flex">
                                            <a class="btn btn-md-square rounded-circle me-3" href="#"><i class="fab fa-facebook-f"></i></a>
                                            <a class="btn btn-md-square rounded-circle me-3" href="#"><i class="fab fa-twitter"></i></a>
                                            <a class="btn btn-md-square rounded-circle me-3" href="#"><i class="fab fa-instagram"></i></a>
                                            <a class="btn btn-md-square rounded-circle me-0" href="#"><i class="fab fa-linkedin-in"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-lg-6 col-xl-3">
                                    <div class="footer-item">
                                        <h4 class="text-white mb-4">Loan Offers</h4>
                                        <a href="./personal-loan.php"><i class="fas fa-angle-right me-2"></i> Personal Loans</a>
                                        <a href="./business-loan.php"><i class="fas fa-angle-right me-2"></i> Business Loans</a>
                                        <a href="./app.php?apply03"><i class="fas fa-angle-right me-2"></i> Cash Advance</a>
                                        <a href="./home-loan.php"><i class="fas fa-angle-right me-2"></i> Home Loan</a>
                                        <a href="./carloan.php"><i class="fas fa-angle-right me-2"></i> Auto Loan</a>
                                    </div>
                                </div>
                                <div class="col-md-6 col-lg-6 col-xl-3">
                                    <div class="footer-item">
                                        <h4 class="text-white mb-4">Useful Links</h4>
                                        <a href="./about.php"><i class="fas fa-angle-right me-2"></i> About Us</a>
                                        <a href="./personal-loan.php"><i class="fas fa-angle-right me-2"></i> Cash Advance</a>
                                        <a href="./business-loan.php"><i class="fas fa-angle-right me-2"></i> Apply for loan</a>
                                        <a href="./app.php?apply03"><i class="fas fa-angle-right me-2"></i> Cash Advance</a>
                                        <a href="./home-loan.php"><i class="fas fa-angle-right me-2"></i> Home Loan</a>
                                        <a href="./carloan.php"><i class="fas fa-angle-right me-2"></i> Auto Loan</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="pt-5" style="border-top: 1px solid rgba(255, 255, 255, 0.08);">
                            <div class="row g-0">
                                <div class="col-12">
                                    <div class="row g-4">
                                        <div class="col-lg-6 col-xl-4">
                                            <div class="d-flex">
                                                <div class="btn-xl-square bg-primary text-white rounded p-4 me-4">
                                                    <i class="fas fa-map-marker-alt fa-2x"></i>
                                                </div>
                                                <div>
                                                   <!-- <h4 class="text-white">Address</h4> -->
                                                    <p class="mb-0 text-white">49 Avenue Street Louwsburg 3150</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-xl-4">
                                            <div class="d-flex">
                                                <div class="btn-xl-square bg-primary text-white rounded p-4 me-4">
                                                    <i class="fas fa-envelope fa-2x"></i>
                                                </div>
                                                <div>
                                                    <h4 class="text-white">Mail Us</h4>
                                                    <p class="mb-0 text-white">loan@bestpickloans.co.za</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-xl-4">
                                            <div class="d-flex">
                                                <div class="btn-xl-square bg-primary text-white rounded p-4 me-4">
                                                    <i class="fa fa-phone-alt fa-2x"></i>
                                                </div>
                                                <div>
                                                    <h4 class="text-white">Telephone</h4>
                                                    <p class="mb-0  text-white "> Whatsapp: 0736505209, 0719443402</p>
                                                    <p class="mb-0 text-white"> Tel: 0736505209, 0719443402 <br>+27145470012</p>
                                                   
                                                   
                                                   


                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3">
                        <div class="footer-item">
                            <h4 class="text-white mb-4">Newsletter</h4>
                            <p class="text-white mb-3 ">We work all days a week, Please contact us for any inquiry.</p>
                            <div class="">
                <div class="">
                    <h5>Open Hours</h5>
               
                    <ul>
                    <li class="nav-link text-white">We work all days a week, Please contact us for any inquiry.</li>
                        <li class="nav-link text-white">Monday - Friday: 8:00 am - 5:00 pm</li>
                        <li class="nav-link text-white">Saturday: 8:00 am - 1:00 pm</li>
                        <li class="nav-link text-white">Closed</li>
                    </ul>
                </div>
            </div>
                           
                          
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer End -->



 <!-- custom scripts -->
 <script src="https://loan.websitelayout.net/js/main.js"></script>
<!-- jquery -->
<script src="https://loan.websitelayout.net/js/core.min.js"></script>

 <!-- jQuery -->
 <script src="https://loan.websitelayout.net/js/jquery.min.js"></script>


 
    <!-- form plugins js -->
    <script src="https://loan.websitelayout.net/quform/js/plugins.js"></script>

    <!-- form scripts js -->
    <script src="https://loan.websitelayout.net/quform/js/scripts.js"></script>
 
    


<!-- popper js -->
<script src="js/popper.min.js"></script>
<!-- <script src="js/jquery.min.js"></script>-->

<!-- bootstrap -->
<script src="js/bootstrap.mtin.js"></script>

    
<!-- Back to Top -->
<a href="#" class="btn btn-primary btn-lg-square rounded-circle back-to-top"><i class="fa fa-arrow-up"></i></a>   

        
<!-- JavaScript Libraries -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="./style2/lib/wow/wow.min.js"></script>
<script src="./style2/lib/easing/easing.min.js"></script>
<script src="./style2/lib/waypoints/waypoints.min.js"></script>
<script src="./style2/lib/counterup/counterup.min.js"></script>
<script src="./style2/lib/lightbox/js/lightbox.min.js"></script>
<script src="./style2/lib/owlcarousel/owl.carousel.min.js"></script>


<!-- Template Javascript -->
<script src="./style2/js/main.js"></script>    <!-- Footer Section End -->

    <!-- Search Begin -->
    <div class="search-model">
        <div class="h-100 d-flex align-items-center justify-content-center">
            <div class="search-close-switch">+</div>
            <form class="search-model-form">
                <input type="text" id="search-input" placeholder="Search here.....">
            </form>
        </div>
    </div>
    <!-- Search End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.nicescroll.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
</body>

</html>