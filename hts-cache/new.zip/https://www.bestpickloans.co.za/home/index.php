<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Best Pick  Loan  (PTY) Ltd ">
    <meta name="keywords" content="Best Pick  Loan (Pty), Quick cash loan, Easy loan, Loan company">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Best Pick  Loan (Pty) Ltd| Personal Loan</title>
    <link rel="shortcut icon" href="./img/choose/choose-5.png" type="image/x-icon">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700;900&display=swap" rel="stylesheet">
    <link rel="shortcut icon" href="./img/favicon.png">
    <!-- Css Styles -->
 
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
   
    <link rel="stylesheet" href="css/style.css" type="text/css">

</head>

<body data-new-gr-c-s-check-loaded="14.1168.0" data-gr-ext-installed="">
    <!-- Page Preloder -->
    <link rel="stylesheet" href="./plugins.css" type="text/css">
<link rel="stylesheet" href="./pluinstyle.css" type="text/css">
 <!-- theme core css -->
 

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@icon/themify-icons@1.0.1-alpha.3/themify-icons.min.css">

     <!-- Libraries Stylesheet -->
     <link rel="stylesheet" href="./style2/lib/animate/animate.min.css"/>
        <link href="./style2/lib/lightbox/css/lightbox.min.css" rel="stylesheet">
        <link href="./style2/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

        <!-- Customized Bootstrap Stylesheet -->
        <link href="./style2/css/bootstrap.min.css" rel="stylesheet">
        <!-- Template Stylesheet -->
        <link href="./style2/css/style.css" rel="stylesheet">

        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

        <!-- Icon Font Stylesheet -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    
    <!--Animation--> 
    <link href="./css/aos.css" rel="stylesheet">
    <!--Animation Script--> 
<script src="./js/aos.js"></script>
        <script>
        AOS.init();
        </script>


<!--
<div id="preloder">
    <div class="loader"></div>
</div>-->

  <!-- Spinner Start -->
  <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

<style>
.bg-gradient-pink{
    background: #CF327B;
 
}
</style>

<!-- Offcanvas Menu Begin -->
<div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel"  style="z-index:111111111 !important;">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasRightLabel"> <h1 class="text-primary mb-0 ms-2"><small> <img src="./img/logo.png" alt="" srcset=""> </small></h1></h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
  <a href="./app.php?a23c66w8-329b-4e67-9169-c5f5899dee4f" class="btn btn-primary rounded-pill py-2 px-4 ms-3 flex-shrink-0 mb-3"> Get Loan <i class="fa fa-arrow-right"></i> </a>
<ul class="list-style1 list-unstyled mb-0 ps-0">
    <li><a href="./index.php">Home  <i class="ti ti-arrow-right"></i></li>
    <li><a href="./personal-loan.php">Personal Loan <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./business-loan.php">Business Loan <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./home-loan.php">Home Loan <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./education-loan.php">Education Loan <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./carloan.php">Auto Loan <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./insurance.php">Insurance <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./about.php">About us  <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./testmonial.php">Testimonials  <i class="ti ti-arrow-right"></i></a></li>
     <li><a href="./contact.php">Contact us  <i class="ti ti-arrow-right"></i></a></li>
  
   
</ul>

                                    
  </div>
</div>
        <!-- Topbar Start -->
        <div class="container-fluid topbar px-0 px-lg-4 bg-light py-2 d-block">
            <div class="container">
                <div class="row gx-0 align-items-center">
                    <div class="col-lg-8 text-center text-lg-start mb-lg-0">
                        <div class="d-flex">
                            <div class="border-end border-dark pe-3">
                                <a href="#" class="text-muted small"><i class="bi bi-whatsapp text-primary me-2"></i> 0736505209, +27145470012</a>
                            </div>
                            <div class="ps-3">
                                <a href="mailto:loan@bestpickloans.co.za" class="text-muted small"><i class="fas fa-envelope text-primary me-2"></i>loan@bestpickloans.co.za</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 text-center text-lg-end">
                        <div class="d-flex justify-content-end">
                            <div class="d-flex border-end border-primary pe-3 d-none d-lg-block">
                                <a class="btn p-0 text-dark me-3" href="#"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn p-0 text-dark me-3" href="#"><i class="fab fa-twitter"></i></a>
                                <a class="btn p-0 text-dark me-3" href="#"><i class="fab fa-instagram"></i></a>
                                <a class="btn p-0 text-dark me-0" href="#"><i class="fab fa-linkedin-in"></i></a>
                            </div>
                            <div class="dropdown ms-3">
                                <a href="#" class="dropdown-toggle text-dark" data-bs-toggle="dropdown"><small><i class="fas fa-globe-europe text-primary me-2"></i> English</small></a>
                                <div class="dropdown-menu rounded">
                                    <a href="#" class="dropdown-item">English</a>
                                    <a href="#" class="dropdown-item">Bangla</a>
                                    <a href="#" class="dropdown-item">French</a>
                                    <a href="#" class="dropdown-item">Spanish</a>
                                    <a href="#" class="dropdown-item">Arabic</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Topbar End -->


      <!-- Navbar & Hero Start -->
     
<div class="container-fluid nav-bar px-0 px-lg-4 py-lg-0">
            <div class="">
                <nav class="navbar navbar-expand-lg navbar-light"> 
                    <a href="#" class="navbar-brand p-0">
                        <h3 class="text-dark mb-0 ms-2"><i class="fab fas-seadling me-2"></i><small><img src="./img/logo.png" alt="" srcset="" class="w-100"></small></h3>
                        <!-- <img src="img/logo.png" alt="Logo"> -->
                    </a>
                    <button class="navbar-toggler me-2" type="button" data-bs-toggle="offcanvas" href="#offcanvasRight" role="button" aria-controls="offcanvasRight">
                        <span class="fa fa-bars"></span>
                    </button>
                    <div class="navbar-collapse collapse" id="navbarCollapse" style="">
                        <div class="navbar-nav mx-0 mx-lg-auto">
                            <a href="./index.php" class="nav-item nav-link active">Home</a>
                            <a href="./about.php" class="nav-item nav-link">About</a>
                         
                        
                            <div class="nav-item dropdown">
                                <a href="#" class="nav-link" data-bs-toggle="dropdown">
                                    <span class="dropdown-toggle">Loan Services</span>
                                </a>
                                <div class="dropdown-menu">
                                    <a href="./personal-loan.php" class="dropdown-item">Personal Loans</a>
                                    <a href="./business-loan.php" class="dropdown-item">Business Loans</a>
                                    <a href="./home-loan.php" class="dropdown-item">Home Loan</a>
                                    <a href="./education-loan.php" class="dropdown-item">Education Loan</a>
                                    <a href="./carloan.php" class="dropdown-item">Auto Loan</a>
                                </div>
                            </div>
                            <a href="./insurance.php" class="nav-item nav-link">Insurance</a>
                            <a href="./testmonial.php" class="nav-item nav-link">Testimonial</a>
                            <a href="./contact.php" class="nav-item nav-link">Contact us</a>
                            <a href="./app.php?a23c66w8-329b-4e67-9169-c5f5899dee4f" class="btn btn-primary rounded-pill py-2 px-4 ms-3 flex-shrink-0"> Get Loan <i class="fa fa-arrow-right"></i> </a>
                           
                        </div>
                    </div>
                    <div class="d-none d-xl-flex flex-shrink-0 ps-4">
                        <a href="#" class="btn btn-primary btn-lg-square rounded-circle position-relative wow tada" data-wow-delay=".9s" style="visibility: visible; animation-delay: 0.9s; animation-name: tada;">
                            <i class="bi bi-whatsapp fa-2x"></i>
                            <div class="position-absolute" style="top: 7px; right: 12px;">
                               <!-- <span><i class="fa fa-comment-dots text-secondary"></i></span>-->
                            </div>
                        </a>
                        <div class="d-flex flex-column ms-3">
                            <span class="text-primary fw-bolder">Whatsapp support</span>
                            <a href="tel: 0736505209"><span class="text-dark"> 0736505209</span></a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>

     
        <!-- Navbar & Hero End -->

        <!-- Modal Search Start -->
        <div class="modal fade" id="searchModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content rounded-0">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Search by keyword</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body d-flex align-items-center bg-primary">
                        <div class="input-group w-75 mx-auto d-flex">
                            <input type="search" class="form-control p-3" placeholder="keywords" aria-describedby="search-icon-1">
                            <span id="search-icon-1" class="btn bg-light border nput-group-text p-3"><i class="fa fa-search"></i></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal Search End -->


<div class="">

        <!--Carousel Start -->
        <div class="header-carousel owl-carousel">
            <div class="header-carousel-item " style="background-image:url('https://images.stockcake.com/public/e/6/7/e6783750-cbb3-4fd7-9b6a-548038000f66_large/joyful-friends-together-stockcake.jpg');background-repeat: no-repeat;background-size:cover;background-position:center center;background-blend-mode:multiply;background-color: #3e4555;">
                <div class="carousel-caption">
                    <div class="container-fluid">
<div class="container">  
                        <div class="row g-4 align-items-center justify-content-center">
                            <div class="col-lg-12 animated fadeInLeft">
                                <div class="text-sm-center text-md-center">
                                    <h4 class="text-white text-uppercase fw-bold mb-4">Welcome To Best Pick  Loan (Pty) Ltd</h4>
                                    <h1 class="display-1 text-white mb-4">Affordable Personal Loans</h1>
                                    <p class="mb-5 fs-5 text-white">Discover affordable personal loans at Capfin. Apply online, check your loan status, and get personalised offers. Quick, easy, and secure.
                                    </p>
                                    <div class="d-flex justify-content-center justify-content-md-center flex-shrink-0 mb-4">
                                        <a class="btn btn-light rounded-pill py-3 px-4 px-md-5 me-2" href="./app.php?apply002">Apply online now <i class="fas fa-play-circle me-2"></i> </a>
                                        <a class="btn btn-dark rounded-pill py-3 px-4 px-md-5 ms-2" href="./about.php">Learn More</a>
                                    </div>
                                </div>
                            </div>
                          <!--  <div class="col-lg-6 animated fadeInRight">
                                <div class="calrousel-img" style="object-fit: cover;">
                                    <img src="https://images.stockcake.com/public/f/8/8/f88432b1-be27-4385-bf78-fff4e43e3a48_large/joyful-urban-moment-stockcake.jpg" class="img-fluid w-100" alt="">
                                </div>
                            </div>-->
                        </div></div>

                    </div>
                </div>
            </div>
            <div class="header-carousel-item " style="background-image:url('https://images.stockcake.com/public/e/7/4/e749da7a-f83b-4f7b-b04d-2325809a877a_large/joyful-group-interaction-stockcake.jpg');background-repeat: no-repeat;background-size:cover;background-position:center center;background-blend-mode:multiply;background-color: #3e4555;">
                <div class="carousel-caption">
                    <div class="container">
                        <div class="row gy-4 gy-lg-0 gx-0 gx-lg-5 align-items-center">
                          <!--  <div class="col-lg-5 animated fadeInLeft">
                                <div class="calrousel-img">
                                    <img src="https://images.stockcake.com/public/9/f/0/9f087277-954e-4863-9bc6-79a9393a0a42_large/joyful-digital-interaction-stockcake.jpg" class="img-fluid w-100" alt="">
                                </div>
                            </div>-->
                            <div class="col-lg-12 animated fadeInRight">
                                <div class="text-sm-center text-md-center">
                                    <h4 class="text-white text-uppercase fw-bold mb-4">Low Interest Loans</h4>
                                    <h1 class="display-1 text-white mb-4">Online Loan Application</h1>
                                    <p class="mb-5 fs-5 text-white">Get a personal loan up to R350 000 with the lowest interest rate of 5% and flexible repayment plans. Apply online now.
                                    <div class="d-flex justify-content-center justify-content-md-center flex-shrink-0 mb-4">
                                        <a class="btn btn-light rounded-pill py-3 px-4 px-md-5 me-2" href="./app.php?quotes"><i class="fas fa-play-circle me-2"></i> Get Started</a>
                                        <a class="btn btn-dark rounded-pill py-3 px-4 px-md-5 ms-2" href="./personal-loan.php">Personal Loan</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Carousel End -->

</div>
 <!-- Service Start -->
 <div class="container-fluid service py-5">
            <div class="container py-5">
                <div class="text-center mx-auto pb-5 wow fadeInUp" data-wow-delay="0.2s" style="max-width: 800px;">
                    <h4 class="text-primary">Our Services</h4>
                    <h1 class="display-4 mb-4">South African best Loan Service Company</h1>
                    <p class="mb-0">Same day pay-out (less than 24hours from application to money in your bank). T's&C’s apply
                    </p>
                </div>
                <div class="row g-4 justify-content-center">
                    <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.2s">
                        <div class="service-item">
                            <div class="service-img">
                                <img src="https://images.stockcake.com/public/b/a/4/ba430ddd-4f88-4284-9fd3-c2c94af58b22_large/car-sold-joy-stockcake.jpg" class="img-fluid rounded-top w-100" alt="">
                                <div class="service-icon p-3">
                                    <i class="fa fa-users fa-2x"></i>
                                </div>
                            </div>
                            <div class="service-content p-4">
                                <div class="service-content-inner">
                                    <a href="#" class="d-inline-block h4 mb-4">Auto Loan</a>
                                    <p class="mb-4">Get started with our auto loan..</p>
                                    <a class="btn btn-primary rounded-pill py-2 px-4" href="./app.php?apply01">Apply </a>
                                    <a class="btn btn-primary rounded-pill py-2 px-4" href="./carloan.php">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.4s">
                        <div class="service-item">
                            <div class="service-img">
                                <img src="https://images.stockcake.com/public/8/2/4/824eb313-88cb-442b-99ef-d8039947a0d2_large/urban-tech-connection-stockcake.jpg" class="img-fluid rounded-top w-100" alt="">
                                <div class="service-icon p-3">
                                    <i class="fa fa-hospital fa-2x"></i>
                                </div>
                            </div>
                            <div class="service-content p-4">
                                <div class="service-content-inner">
                                    <a href="#" class="d-inline-block h4 mb-4">Personal Loan</a>
                                    <p class="mb-4">Whatever your purchasing needs are, we'll help you find, finance and get cover for your vehicle... </p>
                                    <a class="btn btn-primary rounded-pill py-2 px-4" href="./app.php?apply01">Apply </a>
                                    <a class="btn btn-primary rounded-pill py-2 px-4" href="./carloan.php">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.6s">
                        <div class="service-item">
                            <div class="service-img">
                                <img src="https://images.stockcake.com/public/5/2/b/52b37bd8-9945-4f82-91b1-adf06f031b72_large/outdoor-business-lunch-stockcake.jpg" class="img-fluid rounded-top w-100" alt="">
                                <div class="service-icon p-3">
                                    <i class="fa fa-car fa-2x"></i>
                                </div>
                            </div>
                            <div class="service-content p-4">
                                <div class="service-content-inner">
                                    <a href="#" class="d-inline-block h4 mb-4">Business Loan</a>
                                    <p class="mb-4">Grow your Business with Funding of up to R5 000 000 Apply Online , Get Approval in Minutes..</p>
                                    <a class="btn btn-primary rounded-pill py-2 px-4" href="./app.php?apply03">Apply</a>
                                    <a class="btn btn-primary rounded-pill py-2 px-4" href="./business-loan.php">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.8s">
                        <div class="service-item">
                            <div class="service-img">
                                <img src="https://images.stockcake.com/public/4/c/2/4c2a951e-7162-449e-8e75-3069c42a3d91_large/family-home-sold-stockcake.jpg" class="img-fluid rounded-top w-100" alt="">
                                <div class="service-icon p-3">
                                    <i class="fa fa-home fa-2x"></i>
                                </div>
                            </div>
                            <div class="service-content p-4">
                                <div class="service-content-inner">
                                    <a href="#" class="d-inline-block h4 mb-4">Home Loan</a>
                                    <p class="mb-4">Are you ready to turn the key to your dream home? At Best Pick  Loan  , we're dedicated to making that dream...</p>
                                    <a class="btn btn-primary rounded-pill py-2 px-4" href="./app.php?apply002">Apply</a>
                             
                                        <a class="btn btn-primary rounded-pill py-2 px-4" href="./home-loan.php">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 text-center wow fadeInUp" data-wow-delay="0.2s">
                        <a class="btn btn-primary rounded-pill py-3 px-5" href="./contact.php">Get quote</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Service End -->

<section class="container-fluid">
<div class="py-3 service-14">
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <span class="badge bg-primary rounded-pill px-3 py-1 font-weight-bolder">Get Secured loans</span>
                <h3 class="my-3">At Best Pick  Loan (Pty) Ltd</h3>
                <p>Best Pick  Loan  (PTY) Ltd is a legit and credible south african lending / credit broker, registered (2022/411761/07) and approved (NCRCP19890). We offer loans to people under debt review, Low credit score, and Blacklisted with low interest fee.</p>
             
                <a class="btn bg-primary btn-md mt-3 text-white font-weight-bolder mb-3 rounded-5" href=""><span>Get Loan <i class="bi bi-arrow-right"></i></span></a>
            </div>
            <div class="col-lg-4">
                <div class="mb-4 mb-sm-0">
                    <img class="rounded img-fluid" src="https://images.unsplash.com/photo-1445633743309-b60418bedbf2?q=80&w=1740&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="wrappixel kit" />
                    <div class="mt-3">
                        <h6 class="font-weight-medium">Get a Personal Loan of up to
                        <b>R300 000</b></h6>
                        <p class="mt-3">Explore our personalised interest rates for your loan application. Flexible repayments terms that work for you, choose between 12 to 272 months</p>
                        <a href="javascript:void(0)" class="linking">Learn More</a>
                    </div>
                </div>
            </div>
            <!-- Column -->
            <div class="col-lg-4">
                <div class="mb-4 mb-sm-0">
                    <img class="rounded img-fluid" src="https://images.unsplash.com/photo-1556740738-b6a63e27c4df?q=80&w=1740&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="wrappixel kit" />
                    <div class="mt-3">
                        <h6 class="font-weight-medium">Borrow From R15000 To R8000 000</h6>
                        <p class="mt-3">Apply For A Loan Now — Need cash quickly? Apply now for a payday loan & find out if you qualify for a fast loan.</p>
                        <a href="./app.php" class="linking">Get Started</a>
                    </div>
                </div>
            </div>
            <!-- Column -->
        </div>
    </div>
</div>
</section>



<!--call to action-->
<style>
    @import url(//fonts.googleapis.com/css?family=Montserrat:300,400,500);
.c2a10 {
  font-family: "Montserrat", sans-serif;
  color: #8d97ad;
  font-weight: 300;
  background-size: cover;
  background-attachment: fixed;
  background-position: left center;
}

.c2a10 h1,
.c2a10 h2,
.c2a10 h3,
.c2a10 h4,
.c2a10 h5,
.c2a10 h6 {
  color: #3e4555;
}

.c2a10 .subtitle {
  color: #8d97ad;
  line-height: 24px;
}

.c2a10 .text-box {
  padding: 30px 20px;
}

.c2a10 .both-space {
  margin: 80px 0;
}

.c2a10 .btn-info-gradiant {
  background: #188ef4;
  background: -webkit-linear-gradient(legacy-direction(to right), #188ef4 0%, #316ce8 100%);
  background: -webkit-gradient(linear, left top, right top, from(#188ef4), to(#316ce8));
  background: -webkit-linear-gradient(left, #188ef4 0%, #316ce8 100%);
  background: -o-linear-gradient(left, #188ef4 0%, #316ce8 100%);
  background: linear-gradient(to right, #188ef4 0%, #316ce8 100%);
}

.c2a10 .btn-info-gradiant:hover {
  background: #316ce8;
  background: -webkit-linear-gradient(legacy-direction(to right), #316ce8 0%, #188ef4 100%);
  background: -webkit-gradient(linear, left top, right top, from(#316ce8), to(#188ef4));
  background: -webkit-linear-gradient(left, #316ce8 0%, #188ef4 100%);
  background: -o-linear-gradient(left, #316ce8 0%, #188ef4 100%);
  background: linear-gradient(to right, #316ce8 0%, #188ef4 100%);
}

.c2a10 .btn-md {
  padding: 15px 45px;
  font-size: 16px;
}
</style>
<section class="container-fluid">  
<div class="py-5 c2a10"
    style="background-image:url(https://images.unsplash.com/39/lIZrwvbeRuuzqOoWJUEn_Photoaday_CSD%20%281%20of%201%29-5.jpg?q=80&w=1740&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D)">
    <div class="container">
        <!-- Row -->
        <div class="row">
            <div class="col-md-5 text-center both-space">
                <div class="card">
                    <div class="card-body">
                        <div class="text-box">
                            <h3 class="mb-3">We are Leading Insurance Service</h3>
                            <h6 class="subtitle font-weight-normal">As a top Best Pick  Loan  (PTY) Ltd services company, our aim is to provide unmatched and best financial services. Best Pick  Loan  (PTY) Ltd provides cover for almost all of life's eventualities: From Life Cover to Disability Cover, and from Critical Illness cover to short-term insurance</h6>
                            <a class="btn bg-primary btn-md border-0 text-white mt-3"
                                href="./insurance.php"><span>Learn more <i class="bi bi-arrow-right"></i></span></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</section>
 <!--loan Services-->
 
<!--//loan Services-->

    <section class=" ">
        <div class="container">
            <div class="row align-items-center ">
                <div class="col-lg-6 mb-4 mb-lg-0 card border border-0 shadow py-3">
                    <div class="mx-auto text-center">
                        <img src="https://images.stockcake.com/public/7/2/1/72177592-a7b3-48e7-9449-0e32b258ac98_large/meeting-at-cafe-stockcake.jpg" class="rounded" alt="...">
                    </div>
                </div>
                <div class="col-lg-6 ">
                    <div class="ps-lg-6 ps-xl-10 w-lg-90">
                        <div class="mb-4">
                            <div class="main-title title-left text-primary">Getting a Loan at Best Pick  Loan  (PTY) Ltd LTD<span class="line-left"></span></div>
                            <h2 class="w-90">Application Process
                            </h2>
                        </div>
                        <p class="mb-4">Best Pick  Loan (Pty)offers variety of loan services, even for people Under Debt Review, Blacklisted and Low Credit Score. A lot of South Africans, like you have problems with low credit scores,Blacklisting, paid up loans not updated, written of debts, and debt review removal issues. Best Pick  Loan  (PTY) Ltd aims to assist everyday South Africans, like you, to chieve a state of financial Best Pick  Loan .</p>
                        <p class="mb-4">
                            We’re a Top South Africa’s specialist credit provider. It’s all we do. We work with you to
                            find the best solution to your personal , business and home loan needs.</p>
                        <p class="mb-4">
                            <b>Best Pick  Loan  (PTY) Ltd LTD</b>, is flexible, approachable and service orientated. We’ve
                            pioneered a new way of providing loans by linking you directly to the money markets
                            and passing the savings on to you.
                        </p>
                        <div id="accordion" class="accordion-style">
                            <div class="card mb-3">
                                <div class="card-header" id="headingOne">
                                    <h5 class="mb-0">
                                        <button class="btn btn-link" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">Choose Your Loan</button>
                                    </h5>
                                </div>
                                <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-bs-parent="#accordion">
                                    <div class="card-body position-relative">Find out in two minutes which loan would suit you best, how much you can borrow and what your monthly loan payments would be
                                    </div>
                                </div>
                            </div>
                            <div class="card mb-3">
                                <div class="card-header" id="headingTwo">
                                    <h5 class="mb-0">
                                        <button class="btn btn-link collapsed" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">Next, Easy Application Process</button>
                                    </h5>
                                </div>
                                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-bs-parent="#accordion">
                                    <div class="card-body position-relative">
                                        Apply online. It’s simple, paperless and convenient process. Simply Click the link below to get started.
                                        <hr>
                                        <a href="./app.php?a23c66f8-329b-4e77-9169-c5f5899dee7f" class="nav-link">Apply here <i class="fa fa-arrow-right"></i> </a>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingThree">
                                    <h5 class="mb-0">
                                        <button class="btn btn-link collapsed" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">Cash in your account within 24 hours</button>
                                    </h5>
                                </div>
                                <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-bs-parent="#accordion">
                                    <div class="card-body position-relative">
                                        Once approved your loan will be deposited into your bank account within 24 hours
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="pt-0 ">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 mb-4 mb-lg-0 order-lg-2">
                    <div class="about-img position-relative">
                        <div class="image-box">
                            <div class="image-1"><img src="https://images.stockcake.com/public/f/e/a/feaabe9b-fa23-400d-a8e7-8822656cb089_large/cafe-collaboration-space-stockcake.jpg" class="rounded-5" alt="..."></div>
                            <div class="image-2"><img src="https://loan.websitelayout.net/img/about/about-2.jpg" class="rounded" alt="..."></div>
                        </div>
                        <div class="about-box bg-gradient-pink">
                            <h3 class="h1 text-white">38</h3>
                            <p class="mb-0 text-white">Years of Experience</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 ps-lg-4 ps-xl-7 py-5">
                    <div class="content-box">
                        <div class="main-title title-left">Who We Are<span class="line-left"></span></div>
                        <h2 class="w-lg-90 mb-1-6 mb-lg-1-9">South African best Loan Service Company</h2>
                        <p class="mb-1-9 mb-lg-2"> We represent a new concept in short term loans, even those with a bad credit history may be considered. Offering an unparalleled service to help you get access to quick cash with the minimum of inconvenience. While some competitors may make the application process difficult, may have hidden fees and are inflexible with payment terms, the Lenders we work with try to make everything as simple and easy as possible.</p>
                        <p> Our focus is on making the journey to getting the finance you need as painless as possible. Flexible Loans We offer a flexible service where you can choose exactly how much you need to borrow, in any amount between R10,000 and R20,000,000 AT 5% INTEREST RATE PER YEAR FOR 240 MONTHS (20 YEARS). Our company is entirely South African based which means you can rely on us to be one of the quickest for SA Loans in the world.</p>
                        <div class="row border-md-bottom clearfix pb-md-5 mb-5 mb-md-7">
                            <div class="tab-style1 horizontaltab" style="display: block; width: 100%; margin: 0px;">
                                <ul class="resp-tabs-list hor_1">
                                    <li class="resp-tab-item hor_1 resp-tab-active bg-gradient-pink" aria-controls="hor_1_tab_item-0" role="tab">Read more</li>
                                    <li class="resp-tab-item hor_1" aria-controls="hor_1_tab_item-1" role="tab">Terms &Conditions</li>
                                </ul>
                             
                            </div>
                        </div>
                      <!--  <div class="d-sm-flex justify-content-sm-between align-items-center">
                            <div class="media mb-5 mb-sm-0">
                                <div class="rounded-circle p-2 border"><img src="https://loan.websitelayout.net/img/avatars/avatar-04.jpg" class="rounded-circle" alt="..."></div>
                                <div class="media-body ps-3">
                                    <img src="./img/signature.png" alt="..." width="150">
                                    <p class="mb-0">Founder</p>
                                </div>
                            </div>
                            
                        </div>-->
                    </div>
                </div>
            </div>
        </div>
    </section>

  


    <!-- About Section Begin -->
    <section class="about spad">
        <div class="container">
            <div class="about__content">
                <div class="row">
                    <div class="col-lg-5 order-2">
                        <div class="about__img">
                            <img src="https://rcs.co.za/media/eqhl35ks/loans-get-you-loan-banner-596x382.jpg?format=webp" width="100%" alt="">
                            <a href="#" class="play-btn video-popup"><img src="img/about/video-play.png" alt=""></a>
                        </div>
                    </div>
                    <div class="col-lg-6 offset-lg-1 order-1">
                        <div class="about__text">
                            <h2>See if you qualify, you can apply if you;</h2>
                            
<ul class="list-style2 list-unstyled mb-0">
    <li class="mb-2">Are 18 years and older</li>
    <li class="mb-2">Have a valid National ID or driver’s license</li>
    <li class="mb-2">Have a bank account</li>
    <li>Are employed and earn R1,000 or more per month</li>
    <li>Can provide proof of income documentation</li>
</ul>
<h5 class="mt-3">We’ll need the following documents from you;</h5>

<ul class="list-style2 list-unstyled mb-0">
    <li class="mb-2">A valid National Identity document or Drivers Licence</li>
    <li class="mb-2">Your latest payslip(s) or bank statement(s).</li>
   
</ul>
               

<ul class="list-style1 list-unstyled mb-0 ps-0 mb-3 mt-3">
    <li><a href="#!">Loan Terminology</a></li>
    <li><a href="#!">Loan Terms & Conditions</a></li>
    <li><a href="#!">How to Apply</a></li>
</ul>

                                    
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- About End -->

 <!--Loan Caculator-->
 <section class="container">
 <div class="services__details__calculator">
                <h2>Loan Caculator</h2>
                <div class="row">
                    <div class="col-lg-9 col-md-8">
                        <div class="services__details__calculator__item services__details__calculator__item--first">
                            <p>Loan Amount</p>
                            <div class="price-range-wrap">
                                <div class="price-range ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content">
                                    <div class="ui-slider-range ui-corner-all ui-widget-header"></div>
                                    <span tabindex="0" class="ui-slider-handle ui-corner-all ui-state-default"></span>
                                </div>
                                <div class="range-slider">
                                    <div class="price-input">
                                        <input type="text" id="price">
                                        <span>R</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="services__details__calculator__item services__details__calculator__item--second">
                            <p>Tenor</p>
                            <div class="price-range-wrap">
                                <div class="price-range-month ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content">
                                    <div class="ui-slider-range ui-corner-all ui-widget-header"></div>
                                    <span tabindex="0" class="ui-slider-handle ui-corner-all ui-state-default"></span>
                                </div>
                                <div class="range-slider">
                                    <div class="price-input month">
                                        <input type="text" id="month">
                                        <span>Months</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="services__details__calculator__item services__details__calculator__item--third">
                            <p>Rate Of Interest</p>
                            <div class="price-range-wrap">
                                <div class="price-range-percent ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content">
                                    <div class="ui-slider-range ui-corner-all ui-widget-header"></div>
                                    <span tabindex="0" class="ui-slider-handle ui-corner-all ui-state-default"></span>
                                </div>
                                <div class="range-slider">
                                    <div class="price-input">
                                        <input type="text" id="percent">
                                        <span>Percent</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4">
                        <div class="services__details__calculator__total">
                            <div class="services__details__calculator__total__item">
                                <p>Total Interest Payable</p>
                                <h5>R.22,290</h5>
                            </div>
                            <div class="services__details__calculator__total__item">
                                <p>Total Payment</p>
                                <h5>R.15,08,290</h5>
                            </div>
                            <div class="services__details__calculator__total__item">
                                <p>Your EMI will be per month</p>
                                <h5>R.15,08,290</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </section>
            <!--//Loan Caculator-->

           
 

    <section class="bg-img cover-background" data-overlay-dark="7" data-background="https://rcs.co.za/media/chxdnr2l/home-page-banners-1920x464.jpg?format=webp" style="background-image: url('https://rcs.co.za/media/chxdnr2l/home-page-banners-1920x464.jpg?format=webp')">
            <div class="container">
                <div class="row align-items-center justify-content-center text-center">
                    <div class="col-md-10 col-xl-7">
                        <a class="popup-social-video video_btn mb-4 mb-lg-6" href=""><i class="fas fa-play"></i></a>
                        <h2 class="display-lg-6 text-white mb-0 font-weight-600">How can we make it possible for you?</h2>
                        <p class="text-white mt-3">We create value for our partners and their customers by facilitating the financing, management and execution of successful credit solutions.</p>
                        <p>  <a href="#!" class="butn medium">Get Started</a></p>
                    </div>
                </div>
               
<!--
                <div id="copy-code2" class="mfp-hide white-popup-block popup-copy">
                    <div class="copy-element"><a class="copy-clipboard" data-clipboard-target="#section2">copy</a></div>
                    <pre id="section2" class=" language-html"><code class=" language-html">
<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>section</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>bg-img cover-background<span class="token punctuation">"</span></span> <span class="token attr-name">data-overlay-dark</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>7<span class="token punctuation">"</span></span> <span class="token attr-name">data-background</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>img/bg/bg-04.jpg<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>container<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>row align-items-center justify-content-center text-center<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>col-md-10 col-xl-7<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>a</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>popup-social-video video_btn mb-4 mb-lg-6<span class="token punctuation">"</span></span> <span class="token attr-name">href</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>https://www.youtube.com/watch?v=Dui0844eNsE<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>i</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>fas fa-play<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>i</span><span class="token punctuation">&gt;</span></span><span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>a</span><span class="token punctuation">&gt;</span></span>
                <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>h2</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>display-lg-6 text-white mb-0 font-weight-600<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>See how we work with touch of experience<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>h2</span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>section</span><span class="token punctuation">&gt;</span></span>
                    </code></pre>
                </div>-->
            </div>
        </section>

  
    <!-- Call Section Begin -->
    <section class="call spad bg-primary">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-6">
                    <div class="call__text">
                        <div class="section-title">
                            <h2>Request A Call Back</h2>
                            <p>Need help with Best Pick  Loan ? Contact us by phone, email, or visit a branch. General Enquiries Please email us for general enquires.</p>
                        </div>
                     
                    </div>
                </div>
                <div class="col-lg-6 offset-lg-1 col-md-6">
                    <form action="#" class="call__form">
                        <div class="row">
                            <div class="col-lg-6">
                                <input type="text" placeholder="Name">
                            </div>
                            <div class="col-lg-6">
                                <input type="text" placeholder="Email">
                            </div>
                            <div class="col-lg-6">
                                <input type="text" placeholder="Phone">
                            </div>
                            <div class="col-lg-6">
                                <select>
                                    <option value="">Choose Our Services</option>
                                </select>
                            </div>
                        </div>
                        <button type="submit" class="site-btn bg-dark">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- Call Section End -->

    <!--loan Calculator-->


    </section>
    <!-- Blog Section Begin -->
    <section class="latest spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2>More About Loans</h2>
                        <p>We're 100% independent, working only for our customers</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="latest__blog__item">
                        <h5><a href="#">FINANCIAL WELLNESS</a></h5>
                        <p>First-Time personal loan application..</p>
                        <div class="latest__blog__author">
                            <div class="latest__blog__author__pic">
                                <img src="img/latest/lb-1.png" alt="">
                            </div>
                            <div class="latest__blog__author__text">
                                <h6>Best Pick  Loan  (PTY) Ltd </h6>
                                <span>19th March, 2023</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="latest__blog__item">
                        <h5><a href="#">Grow your credit score for even better offers</a></h5>
                        <p>A higher credit score means you’re more likely to be accepted for a wider range of loan
                            rates, so growing your score could give you more offers to choose from...</p>
                        <div class="latest__blog__author">
                            <div class="latest__blog__author__pic">
                                <img src="img/latest/lb-2.png" alt="">
                            </div>
                            <div class="latest__blog__author__text">
                                <h6>Best Pick  Loan  (PTY) Ltd </h6>
                                <span> 3rd August, 2021</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6">
                    <div class="latest__blog__item">
                        <h5><a href="#">HEALTHY CREDIT HABITS FOR A HEALTHIER FUTURE</a></h5>
                        <p>First, the bad news: Good habits normally need to be taught. Most of us aren’t born wanting
                            to work on projects before they’re due or cover our mouths when we sneeze..</p>
                        <div class="latest__blog__author">
                            <div class="latest__blog__author__pic">
                                <img src="img/latest/lb-3.png" alt="">
                            </div>
                            <div class="latest__blog__author__text">
                                <h6>Best Pick  Loan  (PTY) Ltd </h6>
                                <span>9th September, 2021</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12 text-center">
                    <a href="#" class="primary-btn">View More</a>
                </div>
            </div>


         
           
        </div>
    </section>
    <!-- Blog Section End -->



    <!-- Footer Section Begin -->
    <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/6738e5ff2480f5b4f59f10fd/1icr44s5a';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

<script>
        // JavaScript to hide the preloader and show the main content
        window.addEventListener('load', function() {
            document.getElementById('preloader').style.display = 'none';
            document.getElementById('main-content').style.display = 'block';
        });
      
    </script>

<script>
    var TxtType = function(el, toRotate, period) {
	this.toRotate = toRotate;
	this.el = el;
	this.loopNum = 0;
	this.period = parseInt(period, 10) || 2000;
	this.txt = '';
	this.tick();
	this.isDeleting = false;
};

TxtType.prototype.tick = function() {
	var i = this.loopNum % this.toRotate.length;
	var fullTxt = this.toRotate[i];

	if (this.isDeleting) {
		this.txt = fullTxt.substring(0, this.txt.length - 1);
	} else {
		this.txt = fullTxt.substring(0, this.txt.length + 1);
	}

	this.el.innerHTML = '<span class="wrap">'+this.txt+'</span>';

	var that = this;
	var delta = 200 - Math.random() * 100;

	if (this.isDeleting) { delta /= 2; }

	if (!this.isDeleting && this.txt === fullTxt) {
		delta = this.period;
		this.isDeleting = true;
	} else if (this.isDeleting && this.txt === '') {
		this.isDeleting = false;
		this.loopNum++;
		delta = 500;
	}

	setTimeout(function() {
		that.tick();
	}, delta);
};

window.onload = function() {
	var elements = document.getElementsByClassName('typewrite');
	for (var i=0; i<elements.length; i++) {
		var toRotate = elements[i].getAttribute('data-type');
		var period = elements[i].getAttribute('data-period');
		if (toRotate) {
			new TxtType(elements[i], JSON.parse(toRotate), period);
		}
	}
	// INJECT CSS
	var css = document.createElement("style");
	css.type = "text/css";
	css.innerHTML = ".typewrite > .wrap { border-right: 0.08em solid transparent}";
	document.body.appendChild(css);
};
</script>

<section>
            <div class="container">
                <div class="row justify-content-center">

                    <div class="col-lg-9">

                        <div class="position-relative elements-block">

                            <div class="inner-title">
                                <div class="main-title title-left mb-0">Frequently Asked Questions
                                    <span class="line-left"></span>
                                </div>
                            </div>

                            <div id="accordion" class="accordion-style">
                                <div class="card">
                                    <div class="card-header" id="headingOne">
                                        <h5 class="mb-0">
                                            <button class="btn btn-link" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">How do I apply for a loan at Best Pick  Loan  (PTY) Ltd ?</button>
                                        </h5>
                                    </div>
                                    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-bs-parent="#accordion">
                                        <div class="card-body position-relative">
                                        You can apply for an Best Pick  Loan  (PTY) Ltd by clicking here or you can call us at loan@bestpickloans.co.za
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingTwo">
                                        <h5 class="mb-0">
                                            <button class="btn btn-link collapsed" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">How do I pay my monthly loan instalment?</button>
                                        </h5>
                                    </div>
                                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-bs-parent="#accordion">
                                        <div class="card-body position-relative">
                                        Your monthly loan instalment will be automatically debited from your bank account on a date you selected at time of application.
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingThree">
                                        <h5 class="mb-0">
                                            <button class="btn btn-link collapsed" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">Can I apply and be offered a loan if I have a Bad Credit Profile?</button>
                                        </h5>
                                    </div>
                                    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-bs-parent="#accordion">
                                        <div class="card-body position-relative">
                                        Whether you are Blacklisted,Debt Review or your Credit Score is very low, you can apply for a loan. At Best Pick  Loan   Service Loan company, we help you removed blacklisted and increase credit score.
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingFour">
                                        <h5 class="mb-0">
                                            <button class="btn btn-link collapsed" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">Do I need to pay upfront fee before getting a Loan ?</button>
                                        </h5>
                                    </div>
                                    <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-bs-parent="#accordion">
                                        <div class="card-body position-relative">
                                        Best Pick  Loan  (PTY) Ltd do not charge client with good credit profile. However, you only make payment for upfront fee payment if your a having low credit score, blacklisted or Debt review. This fee is also refunded when you make payment on our last instalment.
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingFive">
                                        <h5 class="mb-0">
                                            <button class="btn btn-link collapsed" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">Can I apply for a loan outside South Africa?</button>
                                        </h5>
                                    </div>
                                    <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-bs-parent="#accordion">
                                        <div class="card-body position-relative">
                                        Best Pick  Loan  (PTY) Ltd  application process is online-based. Whether you reside in South Africaor any part of the world. Best Pick  Loan  (PTY) Ltd company accept clients from all part of the world. So long you have all valid required documents.
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="copy-element"><a class="copy-clipboard" data-clipboard-target="#section">Copy</a></div>
                           

                            <div id="copy-code" class="mfp-hide white-popup-block popup-copy">
                                <div class="copy-element"><a class="copy-clipboard" data-clipboard-target="#section">copy</a></div>
                                <pre id="section" class=" language-html"><code class=" language-html">
<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>accordion<span class="token punctuation">"</span></span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>accordion-style<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-header<span class="token punctuation">"</span></span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingOne<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>h5</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>mb-0<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>button</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>btn btn-link<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-toggle</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-target</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#collapseOne<span class="token punctuation">"</span></span> <span class="token attr-name">aria-expanded</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>true<span class="token punctuation">"</span></span> <span class="token attr-name">aria-controls</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseOne<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>How quick will my credit be subsidized?<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>button</span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>h5</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseOne<span class="token punctuation">"</span></span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse show<span class="token punctuation">"</span></span> <span class="token attr-name">aria-labelledby</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingOne<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-parent</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#accordion<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-body position-relative<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised.
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-header<span class="token punctuation">"</span></span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingTwo<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>h5</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>mb-0<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>button</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>btn btn-link collapsed<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-toggle</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-target</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#collapseTwo<span class="token punctuation">"</span></span> <span class="token attr-name">aria-expanded</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>false<span class="token punctuation">"</span></span> <span class="token attr-name">aria-controls</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseTwo<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>What is outsourced financial support?<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>button</span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>h5</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseTwo<span class="token punctuation">"</span></span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">aria-labelledby</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingTwo<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-parent</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#accordion<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-body position-relative<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-header<span class="token punctuation">"</span></span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingThree<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>h5</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>mb-0<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>button</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>btn btn-link collapsed<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-toggle</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-target</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#collapseThree<span class="token punctuation">"</span></span> <span class="token attr-name">aria-expanded</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>false<span class="token punctuation">"</span></span> <span class="token attr-name">aria-controls</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseThree<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>How long is an affirmed financing cost and credit offer substantial?<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>button</span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>h5</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseThree<span class="token punctuation">"</span></span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">aria-labelledby</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingThree<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-parent</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#accordion<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-body position-relative<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-header<span class="token punctuation">"</span></span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingFour<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>h5</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>mb-0<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>button</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>btn btn-link collapsed<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-toggle</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-target</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#collapseFour<span class="token punctuation">"</span></span> <span class="token attr-name">aria-expanded</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>false<span class="token punctuation">"</span></span> <span class="token attr-name">aria-controls</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseFour<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>What sorts of commercial enterprise financing do you offer?<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>button</span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>h5</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseFour<span class="token punctuation">"</span></span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">aria-labelledby</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingFour<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-parent</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#accordion<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-body position-relative<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-header<span class="token punctuation">"</span></span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingFive<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>h5</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>mb-0<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>button</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>btn btn-link collapsed<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-toggle</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-target</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#collapseFive<span class="token punctuation">"</span></span> <span class="token attr-name">aria-expanded</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>false<span class="token punctuation">"</span></span> <span class="token attr-name">aria-controls</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseFive<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>How might I roll out an improvement to my application?<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>button</span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>h5</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseFive<span class="token punctuation">"</span></span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">aria-labelledby</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingFive<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-parent</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#accordion<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-body position-relative<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, Making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable.
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
                    </code></pre>
                            </div>

                        </div>

                    </div>

                </div>
            </div>
        </section>



   <!-- Footer Start -->
   <div class="container-fluid footer py-5 wow fadeIn" data-wow-delay="0.2s" style="background: #151533;">
            <div class="container py-5">
                <div class="row g-5">
                    <div class="col-xl-9">
                        <div class="mb-5">
                            <div class="row g-4">
                                <div class="col-md-6 col-lg-6 col-xl-5">
                                    <div class="footer-item">
                                        <a href="index.php" class="p-0">
                                            <h3 class="text-white"><img src="./img/logo.png" /> </h3>
                                            <!-- <img src="img/logo.png" alt="Logo"> -->
                                        </a>
                                        <p class="text-white mb-4">Best Pick  Loan (Pty)is a nationwide brokerage with over years experience in the credit industry that helps clients all over South Africa to obtain Loans.</p>
                                        <div class="footer-btn d-flex">
                                            <a class="btn btn-md-square rounded-circle me-3" href="#"><i class="fab fa-facebook-f"></i></a>
                                            <a class="btn btn-md-square rounded-circle me-3" href="#"><i class="fab fa-twitter"></i></a>
                                            <a class="btn btn-md-square rounded-circle me-3" href="#"><i class="fab fa-instagram"></i></a>
                                            <a class="btn btn-md-square rounded-circle me-0" href="#"><i class="fab fa-linkedin-in"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-lg-6 col-xl-3">
                                    <div class="footer-item">
                                        <h4 class="text-white mb-4">Loan Offers</h4>
                                        <a href="./personal-loan.php"><i class="fas fa-angle-right me-2"></i> Personal Loans</a>
                                        <a href="./business-loan.php"><i class="fas fa-angle-right me-2"></i> Business Loans</a>
                                        <a href="./app.php?apply03"><i class="fas fa-angle-right me-2"></i> Cash Advance</a>
                                        <a href="./home-loan.php"><i class="fas fa-angle-right me-2"></i> Home Loan</a>
                                        <a href="./carloan.php"><i class="fas fa-angle-right me-2"></i> Auto Loan</a>
                                    </div>
                                </div>
                                <div class="col-md-6 col-lg-6 col-xl-3">
                                    <div class="footer-item">
                                        <h4 class="text-white mb-4">Useful Links</h4>
                                        <a href="./about.php"><i class="fas fa-angle-right me-2"></i> About Us</a>
                                        <a href="./personal-loan.php"><i class="fas fa-angle-right me-2"></i> Cash Advance</a>
                                        <a href="./business-loan.php"><i class="fas fa-angle-right me-2"></i> Apply for loan</a>
                                        <a href="./app.php?apply03"><i class="fas fa-angle-right me-2"></i> Cash Advance</a>
                                        <a href="./home-loan.php"><i class="fas fa-angle-right me-2"></i> Home Loan</a>
                                        <a href="./carloan.php"><i class="fas fa-angle-right me-2"></i> Auto Loan</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="pt-5" style="border-top: 1px solid rgba(255, 255, 255, 0.08);">
                            <div class="row g-0">
                                <div class="col-12">
                                    <div class="row g-4">
                                        <div class="col-lg-6 col-xl-4">
                                            <div class="d-flex">
                                                <div class="btn-xl-square bg-primary text-white rounded p-4 me-4">
                                                    <i class="fas fa-map-marker-alt fa-2x"></i>
                                                </div>
                                                <div>
                                                   <!-- <h4 class="text-white">Address</h4> -->
                                                    <p class="mb-0 text-white">49 Avenue Street Louwsburg 3150</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-xl-4">
                                            <div class="d-flex">
                                                <div class="btn-xl-square bg-primary text-white rounded p-4 me-4">
                                                    <i class="fas fa-envelope fa-2x"></i>
                                                </div>
                                                <div>
                                                    <h4 class="text-white">Mail Us</h4>
                                                    <p class="mb-0 text-white">loan@bestpickloans.co.za</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-xl-4">
                                            <div class="d-flex">
                                                <div class="btn-xl-square bg-primary text-white rounded p-4 me-4">
                                                    <i class="fa fa-phone-alt fa-2x"></i>
                                                </div>
                                                <div>
                                                    <h4 class="text-white">Telephone</h4>
                                                    <p class="mb-0  text-white "> Whatsapp: 0736505209, 0719443402</p>
                                                    <p class="mb-0 text-white"> Tel: 0736505209, 0719443402 <br>+27145470012</p>
                                                   
                                                   
                                                   


                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3">
                        <div class="footer-item">
                            <h4 class="text-white mb-4">Newsletter</h4>
                            <p class="text-white mb-3 ">We work all days a week, Please contact us for any inquiry.</p>
                            <div class="">
                <div class="">
                    <h5>Open Hours</h5>
               
                    <ul>
                    <li class="nav-link text-white">We work all days a week, Please contact us for any inquiry.</li>
                        <li class="nav-link text-white">Monday - Friday: 8:00 am - 5:00 pm</li>
                        <li class="nav-link text-white">Saturday: 8:00 am - 1:00 pm</li>
                        <li class="nav-link text-white">Closed</li>
                    </ul>
                </div>
            </div>
                           
                          
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer End -->



 <!-- custom scripts -->
 <script src="https://loan.websitelayout.net/js/main.js"></script>
<!-- jquery -->
<script src="https://loan.websitelayout.net/js/core.min.js"></script>

 <!-- jQuery -->
 <script src="https://loan.websitelayout.net/js/jquery.min.js"></script>


 
    <!-- form plugins js -->
    <script src="https://loan.websitelayout.net/quform/js/plugins.js"></script>

    <!-- form scripts js -->
    <script src="https://loan.websitelayout.net/quform/js/scripts.js"></script>
 
    


<!-- popper js -->
<script src="js/popper.min.js"></script>
<!-- <script src="js/jquery.min.js"></script>-->

<!-- bootstrap -->
<script src="js/bootstrap.mtin.js"></script>

    
<!-- Back to Top -->
<a href="#" class="btn btn-primary btn-lg-square rounded-circle back-to-top"><i class="fa fa-arrow-up"></i></a>   

        
<!-- JavaScript Libraries -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="./style2/lib/wow/wow.min.js"></script>
<script src="./style2/lib/easing/easing.min.js"></script>
<script src="./style2/lib/waypoints/waypoints.min.js"></script>
<script src="./style2/lib/counterup/counterup.min.js"></script>
<script src="./style2/lib/lightbox/js/lightbox.min.js"></script>
<script src="./style2/lib/owlcarousel/owl.carousel.min.js"></script>


<!-- Template Javascript -->
<script src="./style2/js/main.js"></script>    <!-- Footer Section End -->

    <!-- Search Begin -->
    <div class="search-model">
        <div class="h-100 d-flex align-items-center justify-content-center">
            <div class="search-close-switch">+</div>
            <form class="search-model-form">
                <input type="text" id="search-input" placeholder="Search here.....">
            </form>
        </div>
    </div>
    <!-- Search End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.nicescroll.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
</body>

</html>