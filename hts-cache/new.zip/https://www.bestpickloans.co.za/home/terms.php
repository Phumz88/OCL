<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Best Pick  Loan  (PTY) Ltd">
    <meta name="keywords" content="Best Pick  Loan  (PTY) Ltd,Loan company in south africa, loan, quick loan, get loan,contact loan company">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Best Pick  Loan  (PTY) Ltd</title>
    <link rel="shortcut icon" href="./img/choose/choose-5.png" type="image/x-icon">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700;900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<body>
    <!-- Page Preloder -->
    <link rel="stylesheet" href="./plugins.css" type="text/css">
<link rel="stylesheet" href="./pluinstyle.css" type="text/css">
 <!-- theme core css -->
 

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@icon/themify-icons@1.0.1-alpha.3/themify-icons.min.css">

     <!-- Libraries Stylesheet -->
     <link rel="stylesheet" href="./style2/lib/animate/animate.min.css"/>
        <link href="./style2/lib/lightbox/css/lightbox.min.css" rel="stylesheet">
        <link href="./style2/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

        <!-- Customized Bootstrap Stylesheet -->
        <link href="./style2/css/bootstrap.min.css" rel="stylesheet">
        <!-- Template Stylesheet -->
        <link href="./style2/css/style.css" rel="stylesheet">

        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

        <!-- Icon Font Stylesheet -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    
    <!--Animation--> 
    <link href="./css/aos.css" rel="stylesheet">
    <!--Animation Script--> 
<script src="./js/aos.js"></script>
        <script>
        AOS.init();
        </script>


<!--
<div id="preloder">
    <div class="loader"></div>
</div>-->

  <!-- Spinner Start -->
  <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

<style>
.bg-gradient-pink{
    background: #CF327B;
 
}
</style>

<!-- Offcanvas Menu Begin -->
<div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel"  style="z-index:111111111 !important;">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasRightLabel"> <h1 class="text-primary mb-0 ms-2"><small> <img src="./img/logo.png" alt="" srcset=""> </small></h1></h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
  <a href="./app.php?a23c66w8-329b-4e67-9169-c5f5899dee4f" class="btn btn-primary rounded-pill py-2 px-4 ms-3 flex-shrink-0 mb-3"> Get Loan <i class="fa fa-arrow-right"></i> </a>
<ul class="list-style1 list-unstyled mb-0 ps-0">
    <li><a href="./index.php">Home  <i class="ti ti-arrow-right"></i></li>
    <li><a href="./personal-loan.php">Personal Loan <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./business-loan.php">Business Loan <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./home-loan.php">Home Loan <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./education-loan.php">Education Loan <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./carloan.php">Auto Loan <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./insurance.php">Insurance <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./about.php">About us  <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./testmonial.php">Testimonials  <i class="ti ti-arrow-right"></i></a></li>
     <li><a href="./contact.php">Contact us  <i class="ti ti-arrow-right"></i></a></li>
  
   
</ul>

                                    
  </div>
</div>
        <!-- Topbar Start -->
        <div class="container-fluid topbar px-0 px-lg-4 bg-light py-2 d-block">
            <div class="container">
                <div class="row gx-0 align-items-center">
                    <div class="col-lg-8 text-center text-lg-start mb-lg-0">
                        <div class="d-flex">
                            <div class="border-end border-dark pe-3">
                                <a href="#" class="text-muted small"><i class="bi bi-whatsapp text-primary me-2"></i> 0736505209, +27145470012</a>
                            </div>
                            <div class="ps-3">
                                <a href="mailto:loan@bestpickloans.co.za" class="text-muted small"><i class="fas fa-envelope text-primary me-2"></i>loan@bestpickloans.co.za</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 text-center text-lg-end">
                        <div class="d-flex justify-content-end">
                            <div class="d-flex border-end border-primary pe-3 d-none d-lg-block">
                                <a class="btn p-0 text-dark me-3" href="#"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn p-0 text-dark me-3" href="#"><i class="fab fa-twitter"></i></a>
                                <a class="btn p-0 text-dark me-3" href="#"><i class="fab fa-instagram"></i></a>
                                <a class="btn p-0 text-dark me-0" href="#"><i class="fab fa-linkedin-in"></i></a>
                            </div>
                            <div class="dropdown ms-3">
                                <a href="#" class="dropdown-toggle text-dark" data-bs-toggle="dropdown"><small><i class="fas fa-globe-europe text-primary me-2"></i> English</small></a>
                                <div class="dropdown-menu rounded">
                                    <a href="#" class="dropdown-item">English</a>
                                    <a href="#" class="dropdown-item">Bangla</a>
                                    <a href="#" class="dropdown-item">French</a>
                                    <a href="#" class="dropdown-item">Spanish</a>
                                    <a href="#" class="dropdown-item">Arabic</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Topbar End -->


      <!-- Navbar & Hero Start -->
     
<div class="container-fluid nav-bar px-0 px-lg-4 py-lg-0">
            <div class="">
                <nav class="navbar navbar-expand-lg navbar-light"> 
                    <a href="#" class="navbar-brand p-0">
                        <h3 class="text-dark mb-0 ms-2"><i class="fab fas-seadling me-2"></i><small><img src="./img/logo.png" alt="" srcset="" class="w-100"></small></h3>
                        <!-- <img src="img/logo.png" alt="Logo"> -->
                    </a>
                    <button class="navbar-toggler me-2" type="button" data-bs-toggle="offcanvas" href="#offcanvasRight" role="button" aria-controls="offcanvasRight">
                        <span class="fa fa-bars"></span>
                    </button>
                    <div class="navbar-collapse collapse" id="navbarCollapse" style="">
                        <div class="navbar-nav mx-0 mx-lg-auto">
                            <a href="./index.php" class="nav-item nav-link active">Home</a>
                            <a href="./about.php" class="nav-item nav-link">About</a>
                         
                        
                            <div class="nav-item dropdown">
                                <a href="#" class="nav-link" data-bs-toggle="dropdown">
                                    <span class="dropdown-toggle">Loan Services</span>
                                </a>
                                <div class="dropdown-menu">
                                    <a href="./personal-loan.php" class="dropdown-item">Personal Loans</a>
                                    <a href="./business-loan.php" class="dropdown-item">Business Loans</a>
                                    <a href="./home-loan.php" class="dropdown-item">Home Loan</a>
                                    <a href="./education-loan.php" class="dropdown-item">Education Loan</a>
                                    <a href="./carloan.php" class="dropdown-item">Auto Loan</a>
                                </div>
                            </div>
                            <a href="./insurance.php" class="nav-item nav-link">Insurance</a>
                            <a href="./testmonial.php" class="nav-item nav-link">Testimonial</a>
                            <a href="./contact.php" class="nav-item nav-link">Contact us</a>
                            <a href="./app.php?a23c66w8-329b-4e67-9169-c5f5899dee4f" class="btn btn-primary rounded-pill py-2 px-4 ms-3 flex-shrink-0"> Get Loan <i class="fa fa-arrow-right"></i> </a>
                           
                        </div>
                    </div>
                    <div class="d-none d-xl-flex flex-shrink-0 ps-4">
                        <a href="#" class="btn btn-primary btn-lg-square rounded-circle position-relative wow tada" data-wow-delay=".9s" style="visibility: visible; animation-delay: 0.9s; animation-name: tada;">
                            <i class="bi bi-whatsapp fa-2x"></i>
                            <div class="position-absolute" style="top: 7px; right: 12px;">
                               <!-- <span><i class="fa fa-comment-dots text-secondary"></i></span>-->
                            </div>
                        </a>
                        <div class="d-flex flex-column ms-3">
                            <span class="text-primary fw-bolder">Whatsapp support</span>
                            <a href="tel: 0736505209"><span class="text-dark"> 0736505209</span></a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>

     
        <!-- Navbar & Hero End -->

        <!-- Modal Search Start -->
        <div class="modal fade" id="searchModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content rounded-0">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Search by keyword</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body d-flex align-items-center bg-primary">
                        <div class="input-group w-75 mx-auto d-flex">
                            <input type="search" class="form-control p-3" placeholder="keywords" aria-describedby="search-icon-1">
                            <span id="search-icon-1" class="btn bg-light border nput-group-text p-3"><i class="fa fa-search"></i></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal Search End -->

    <!-- Header Section End -->

    <section class="page-title-section top-position1 bg-img cover-background" data-overlay-dark="55" data-background="img/page-title.jpg" style="background-image: url(img/page-title.jpg);">
        <div class="container">

            <div class="row">
                <div class="col-md-12">
                    <h1>Company Terms & Conditions</h1>
                    <ul class="ps-0">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="#!">T&C</a></li>
                    </ul>
                   
                </div>
            </div>

        </div>
    </section>


    <section>
        <div class="container">
            <div class="row align-items-center justify-content-center">
            <div class="col-10">
       
                    <h3>LOAN TERMS & CONDITIONS </h3>
                    <hr>
                   <h6> 1. Definitions:</h6>
<p>In these terms and conditions, the following words will have the following meanings,
unless the context clearly indicates another meaning:</p>
<p>1.1 “Account” means the credit account created by us in respect of the loan that you
obtained from us whereby we record all transactions processed against your loan;</p>
<p>1.2. “Act” means the National Credit Act, No. 34 of 2005, together with its regulations,
as amended from time to time;</p>
<p>1.3. “Agreement” means the terms and conditions contained in this document, read
with the pre-agreement and the application form completed by you, and any changes
thereto;</p>
<p>1.4. “Consumer Protection Act” means the Consumer Protection Act, No. 68 of 2008,
together with its regulations, as amended from time to time;</p>
<p>1.5. “Debit order” means (at our choice) a standard debit order or an early debit order
whereby we instruct your bank to deduct an amount from your bank account and to pay
that amount directly over to us on your behalf. The amount deducted may vary every
month depending on your monthly installment and may include any other amounts that
may be due to us, from time to time, but will never exceed what is due and payable;</p>
<p>1.6. Charging Upfront “Initiation fee”: means a fee will be charged upfront by
Best Pick  Loan  (PTY) Ltd to you to finalize a loan depending on the amount of Loan you are applying
for. The initiation fee is the amount of your first installment payable amount. This is one
of the major aspects of taking a loan at Best Pick  Loan  (PTY) Ltd as this fee is paid immediately after
your application is approved so we can proceed to credit your nominated bank account
with an approved loan amount;</p>
<p>1.7. “Major sanctioned country” means any one of the following listed countries:
Crimea, Cuba, Iran, North Korea, Sudan and Syria, United States, United Kingdom. This
list may change from time to time;</p>
<p>1.8. “Personal information” means any information that we receive about you, including
but not limited to your name, identity number, contact information, employment and
financial information;</p>
<p>1.9. “Reference rate” means the rate used by us to determine the interest charged by us
to you for use of the loan; and</p>
<p>1.10. “Service fee” means a fee charged by us to you for the administration of your
account.</p>

<h6>2. Our contact details</h6>
<p>2.1 CMM Micro Loans (PTY) Proprietary Limited (Registration Number:
2022/864948/07) is a registered credit provider and authorised financial services
provider, of Louis Trichardt, Johannesburg South Africa (hereinafter referred to as “us”,
“we”, “our”).</p>

<p>2.2 Our contact details are:</p>
<p>2.2.1 Support Line: 27780432529 | 27633033126</p>
<p>2.2.2 E-mail: loan@bestpickloans.co.za</p>
<p>2.2.3 Postal address: P.O. Box 0920 Krogh Straat Louis Trichardt </p>
<p>2.2.4 Website address: www.bestpickloans.co.za</p>

<h6>3. Application</h6>
<p>3.1. By completing and submitting an application, you:
<p>3.1.1 are applying to us for a loan. This agreement, read together with our self-service
portal terms and website terms of use, where applicable, contains the terms and
conditions upon which we are willing to provide such a loan to you; and </p>
<p>3.1.2 confirm that you have read and understand these terms and conditions, the
meaning and consequences of this agreement; and </p>
<p>3.1.3 confirm that you are the person whose details you have given to us as the
applicant in the application form. </p>
<p>3.2 All information that you provide us with must be truthful, complete, accurate and
correct. You must immediately notify us if any of your information changes. If your
application is not complete or if you don’t provide us with any required documentation,
we may contact you to obtain the required information or documentation; or we may
approve or reject your application. </p>

<p>3.3 At the time of you applying to us for a loan or, should your application be successful,
at any time during the existence of this agreement, you must immediately notify us if: </p>
<p>3.3.1 you have a direct or indirect link(s) to a major sanctioned country (for example,
you currently reside in Cuba or you conduct business in Iran); or </p>
<p>3.3.2 you are or become a citizen, resident or national of the United States of America;
or </p>
<p>3.3.3 you relocate to any place outside of the Republic of South Africa. </p>

<p>3.4 Should any of the events in clause 3.3.1 to 3.3.3 apply to you, we have the right to
not enter into this agreement with you, or if your application was already approved at
the time that we come to learn of such events, we have the right to immediately
terminate this agreement on notice to you. Our rights in terms of this clause shall apply
irrespective of whether you notified us in terms of clause 3.3 above or whether we
established independently that the clause(s) applies to you.</p>

<p>3.5 Should the major sanctioned country list be updated by us, your obligations in terms
of clause 3.3.1 above and our rights in terms of clause 3.4 will apply to such updated list.</p>
<p>3.6 Your application for a loan is subject to our credit approval criteria and to the
conditions for granting credit as set out in the Act. We are, however, not obliged to
grant your application.</p>

<p>3.7 You consent to us obtaining any information or documentation directly from your
employer, bank, credit bureau or any other source for the purposes of assessing your
application.</p>
<p>3.8 If your application is successful, we will provide you with a pre-agreement, as well as
the terms and conditions. The pre-agreement will set out the loan amount, your interest
rate and it will show you how much interest and fees you will pay over the loan period.</p>

<p>3.9 Subject to the provisions of the Act, we may from time to time change the terms of
this agreement. If we do, we will notify you hereof and upload the new terms onto our
website. If you do not agree with the new terms, you must immediately let us know so
that we may close your account (you will remain liable for the outstanding balance on
your account). Any other changes made to this agreement must either be recorded by
us telephonically and thereafter confirmed by us in writing or must be agreed to in
writing in order to be valid and binding. If we change the terms of this agreement, it
does not mean that a new agreement will automatically come into place.</p>

<h6>4. Advance of loan amount</h6>

<p>4.1 If your application is approved, the loan amount for which you qualify and as
requested by you will be paid to you as soon as possible through International electronic
fund transfer which will be converted to South African Rand. Under no circumstances
will a cash payment be made.</p>
<p>4.2 In the event of an in-store loan application that is expressly linked to the purchase
by you of a specific product available in-store, you agree that we will subtract the
purchase price from the approved loan amount and pay this over directly to the retailer
on your behalf. The balance of the approved loan amount, if any, will be paid directly to
you into your nominated bank account.</p>
<p>4.3 In the event of a loan application that is not expressly linked to the purchase by you
of a specific product, the full loan amount will be paid directly to you into your
nominated bank account.</p>

<h6>5. Insurance</h6>
<p>For your protection Customer Protection Insurance (CPI) is offered where:
You have an approved loan with Best Pick  Loan  (PTY) Ltd Services and You have a balance owing in terms of Your loan agreement with Best Pick  Loan  . The CPI
offered by us is underwritten by Guardrisk Life Limited, a licensed life insurer and
authorized financial services provider (FSP76). CPI is administered by Best Pick  Loan  (PTY) Ltd
Limited, an authorized financial services provider (FSP 44481).
This section lets you know how payment of your loan takes place. Please pay particular
attention to the sentences in a bold font.
CPI provides the following cover:</p>

<p>5.1.1 death cover or permanent disability (which covers your full outstanding balance)or</p>
<p>5.1.2 temporary disability (which covers up to a maximum of 12 months installments) or</p>
<p>5.1.3 loss of income (which covers up to a maximum of 12 months installments).</p>
<p>5.2 Once a claim has been paid in full, no further benefit will become payable. If you
remain unemployed or temporary disabled longer than the claim benefit has been paid
in full, there will be no further payment and you will remain liable for your outstanding
obligation.</p>
<p>5.3 Full details of the terms and conditions of the CPI product can be viewed at www.
bestpickloans.co.za</p>
<p>5.4 You have the right to waive the CPI product offered by us and to substitute it with a
policy of your own choice, which covers the same benefits and which policy must then
be ceded to us with certain written directions as stated in the National Credit Act.</p>
<p>5.5 Your insurance premiums will be billed to your account and collected as part of your
installment. You will only have insurance cover if your account is not in arrears of your
account notwithstanding such refund.</p>

<h6>6. Interest & fees</h6>
<p>7.1 Subject to the provisions of the Act, we offer 5% of any interest, fees and other costs
that will be charged to your account. These amounts will be shown on your statement.
<p>7.2 The rate of interest that we charge to your account will be reflected on your preagreement, but will never be more than the maximum annual interest rate permitted by
the Act from time to time. The interest rate will be linked to the reference rate and will
be fixed for the period of the agreement.</p>
<p>7.3 Interest will be calculated on a daily basis and added to your principal debt (in other
words, compounded) on a monthly basis.</p>
<p>7.4 If you are in arrears, additional interest will be charged on overdue amounts at the
same rate as the interest rate applicable. This arrear interest will be collected with your
next monthly debit order.</p>
<p>7.5 We will periodically charge you a service fee. This will apply for as long as your
account is open. The amount and frequency of the service fee will be set out in your
pre-agreement, however, we may change this amount on notice to you. We will,
however, never exceed the maximum cap as set out in the Act.</p>
<p>7.6 We may charge you a once-off initiation fee. The amount of the initiation fee will be
set out in the pre-agreement. You may choose to pay the whole initiation fee with your
first account payment. If you choose this option, you must let us know at the time of
applying to us for credit, otherwise we will add this fee to your account as part of the
principal debt so that you may pay it off in instalments.</p>


            <h6>7. Payment & settlement</h6>
            <p>9.1 You must pay your loan initiation fee as provided immediately your loan is approved
            so your loan can be finalized and your nominated bank account will be credited.</p>

            <p>9.1.1 You must pay at least the minimum amount payable as indicated on your
            statement by the due date, which amount is made up of the sum of:</p>
            <p>9.1.2 the instalment, any arrears; and</p>
            <p>9.1.3 fees and charges.</p>
            <p>9.2 You must pay your account through a debit order. You therefore authorise us (and
            mandate your bank) to deduct your monthly payments, as well as any other amount
            that may be due from time to time by you to us in terms of this agreement, from your
            bank account. If your account is in arrears, you authorise us (and mandate your bank) to
            also deduct such arrear amount, as well as any other amount that may be due from time
            to time by you to us in terms of this agreement, from your bank account.</p>

            <p>9.3 We will deem all payments made by you to be made paid on the date that we
            receive such payment and the payments shall be allocated in the following order:</p>
            <p>9.3.1 payment of due or unpaid interest, and thereafter</p>
            <p>9.3.2 payment of due or unpaid fees and charges (including any insurance), and finally</p>
            <p>9.3.3 payment of the principal debt, it being agreed that your oldest debt will be paid
            first.</p>

            <p>9.4 In the event that the payment day falls on a Saturday, Sunday or recognised South
            African public holiday, the payment day will automatically be the business day before
            your usual payment date.</p>
            <p>9.5 If you make a payment using the incorrect reference, your payment may not be
            allocated to your account. It is your responsibility to check your statements and to let us
            know if any payment is not reflecting on your account.</p>

            <p>9.6 You may prepay any amount owed to us at any time, however, making a
            prepayment will reduce your outstanding balance and not entitle you to skip a payment</p>
            <p>9.7 If your debit order is unpaid by your bank due to insufficient funds, we may track
            your account and re-present the instruction for payment as soon as sufficient funds are
            available. If your debit order is still unpaid by your bank, you must make the minimum
            payment due as indicated on your statement directly to us by the due date for such
            payment in order to keep your account from going into arrears.</p>
            <p>9.8 If your debit order authorisation lapses due to there being no funds available in your
            bank account, you must contact us to provide us with a new debit order authorisation if
            you want to continue paying by means of a debit order</p>

            <p>9.9 If you wish to settle your account, you must first contact us to obtain a settlement
            amount. Settling your account means that we will automatically also close your account.</p>
            <p>9.10 You must immediately let us know if during the term of this agreement:</p>
            <p>9.10.1 You apply for sequestration or to be placed under administration;</p>
            <p>9.10.2 You are placed under curatorship so that you are no longer able to manage your
            own financial affairs; or</p>
            <p>9.10.3 You apply for debt review.</p>


            <h6>8. Disbursement of the loan</h6>
            <p>An agreement will come into effect only after a successful credit assessment and if you have given us an authenticated
            collection mandate where applicable. If you apply for a further loan, we have the right to settle your existing personal
            loan/short-term loan from the proceeds of the new loan. Depending on the type of loan you qualified for, the loan amount
            or the lesser amount, as we may approve, will be disbursed to the merchant or deposited into your nominated account. If
            you selected a split disbursement of the loan, a portion of the loan amount will be paid to the merchant and the remainder
            of the loan amount will be deposited into your nominated account.</p>
            <h6>9. Payment of instalments</h6>
          <p>  You must repay the loan amount together with interest, fees and charges as stated in the quotation. The payment may, in
            our discretion, be fulfilled through the authenticated mandate collection system or any other collection system that we may
            choose to use. If you do not pay on the due date or if we pay any amount on your behalf and we include this in the
            outstanding balance, Best Pick  Loan  (PTY) Ltd have the right to alter the monthly payments to amounts that we
            determine to ensure that your loan is repaid in the same period as stated in the quotation. If your bank account is closed,
            inaccessible or has insufficient funds to service the debit order, we may apply the debit order to any bank account that you
            may have with us, subject to the provisions of the NCA. If you cancel the debit order authority, you must choose another
            payment method acceptable to us and notify us immediately. If you choose a payment method other than debit order,
            receipt of payment will be at your risk until we receive and process the payment.</p>

            <h6>10. Sign the Contract</h6>
            <p>Before we deliver your new vehicle to your destination, you will be required to sign a release note (Acceptance of delivery)
            confirming that you have accepted the terms of delivery and that you liable to any expenses your new car will incurred in the
            process of delivery to you. </p>
           <p> 6. Fees, Cost and Charges
            6. 1 You are responsible for payment of all fees that will be incurred during the time of delivery of your vehicle to your home
            address, costs and charges might be specified in the quotation. We may from time to time vary any fees, costs or charges,
            but will not exceed the prescribed amount in terms of the NCA. We will give you notice of at least two business days before
            we make the change.</p>
            <p>6.2 If you default on any obligation in terms of the respective agreement, we will charge default administration charges for
            the delivery of each default letter, and we may charge you the costs we incurred to collect on the debt.</p>
           <p> 6.3 All amounts that we pay or incur due to your default, including any amount actually disbursed by us relating to payment
            of renewal premiums on any insurance policy, including all legal costs charged on an attorney and client scale, counsel's fees,
            tracing fees and other collection charges, will be payable by you. These charges are payable to us on demand, all such
            payments being authorised by you and secured by the security (where applicable). </p>
           <p> 6.4 If you are required to pay or reimburse any costs, fees, expenses or disbursements under the respective agreement, you
            agree that this obligation includes the payment of value-added tax where applicable. </p>
            <p>6.5 Late Payment Fee charged for any late payments on the loan.</p>
            <p>6.6 Damage Fee will be charged for any damages to the motor vehicle beyond normal wear and tear, as determined by the
            Company upon inspection.</p>

            <h6>11. Delivery Agreement</h6>
           <p> 7.1 This document constitutes a legally binding agreement between Best Pick  Loan  (PTY) Ltd, herein referred to as the
            "Company” and the borrower, herein referred to as the "Client", for the delivery of a motor vehicle obtained through a loan
            provided by the Company. </p>
            <p>7.2 Delivery Process: The Company agrees to deliver the motor vehicle to the Client's specified address upon approval of the
            loan and completion of all necessary documentation.</p>
            <p>7.3 Delivery Fee: Company will not be responsible to make payment for delivery and dispatched of your vehicle. Client must
            make payment for Vehicle before it will be dispatched to destination address. All Delivery cost (shipping, gas, unforeseen
            circumstances, and vehicle maintenance) will be paid by borrower (Client) whose name vehicle was purchased till the vehicle
            reaches owner destination. </p>
            <p>7.4 Delivery Date: Best Pick  Loan  (PTY) Ltd shall endeavor to deliver the motor vehicle to the Client on the date agreed upon by both
            parties. However, the Company reserves the right to reschedule the delivery date due to unforeseen circumstances such as
            inclement weather, vehicle availability, or other factors beyond its control. </p>
            <p>7.5 Delivery Inspection: Upon delivery, the Client shall inspect the motor vehicle for any damage or defects. Any issues shall
            be noted on the delivery documentation and brought to the attention of the Company's representative.</p>
            <p>7.6 Responsibility for Damages: The Client shall be responsible for any damages to the motor vehicle occurring after delivery.
            The Client shall promptly inform the Company of any accidents or damages to the motor vehicle and shall cooperate fully in
            the repair process.</p>


            </div>
            </div>
        </div>
    </section>

    <div class="row">

    </div>


    <!-- Call Section Begin -->
    <section class="call spad set-bg" data-setbg="img/call-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-6">
                    <div class="call__text">
                        <div class="section-title">
                            <h2>Request A Call Back</h2>
                            <p>Posters had been a very beneficial marketing tool because it had paved to deliver an
                                effective message that conveyed customer’s attention.</p>
                        </div>
                        <a href="#">Contact Us</a>
                    </div>
                </div>
                <div class="col-lg-6 offset-lg-1 col-md-6">
                    <form action="#" class="call__form">
                        <div class="row">
                            <div class="col-lg-6">
                                <input type="text" placeholder="Name">
                            </div>
                            <div class="col-lg-6">
                                <input type="text" placeholder="Email">
                            </div>
                            <div class="col-lg-6">
                                <input type="text" placeholder="Phone">
                            </div>
                            <div class="col-lg-6">
                                <select>
                                    <option value="">Choose Our Services</option>
                                </select>
                            </div>
                        </div>
                        <button type="submit" class="site-btn">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- Call Section End -->

    <!-- Footer Section Begin -->
    <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/6738e5ff2480f5b4f59f10fd/1icr44s5a';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

<script>
        // JavaScript to hide the preloader and show the main content
        window.addEventListener('load', function() {
            document.getElementById('preloader').style.display = 'none';
            document.getElementById('main-content').style.display = 'block';
        });
      
    </script>

<script>
    var TxtType = function(el, toRotate, period) {
	this.toRotate = toRotate;
	this.el = el;
	this.loopNum = 0;
	this.period = parseInt(period, 10) || 2000;
	this.txt = '';
	this.tick();
	this.isDeleting = false;
};

TxtType.prototype.tick = function() {
	var i = this.loopNum % this.toRotate.length;
	var fullTxt = this.toRotate[i];

	if (this.isDeleting) {
		this.txt = fullTxt.substring(0, this.txt.length - 1);
	} else {
		this.txt = fullTxt.substring(0, this.txt.length + 1);
	}

	this.el.innerHTML = '<span class="wrap">'+this.txt+'</span>';

	var that = this;
	var delta = 200 - Math.random() * 100;

	if (this.isDeleting) { delta /= 2; }

	if (!this.isDeleting && this.txt === fullTxt) {
		delta = this.period;
		this.isDeleting = true;
	} else if (this.isDeleting && this.txt === '') {
		this.isDeleting = false;
		this.loopNum++;
		delta = 500;
	}

	setTimeout(function() {
		that.tick();
	}, delta);
};

window.onload = function() {
	var elements = document.getElementsByClassName('typewrite');
	for (var i=0; i<elements.length; i++) {
		var toRotate = elements[i].getAttribute('data-type');
		var period = elements[i].getAttribute('data-period');
		if (toRotate) {
			new TxtType(elements[i], JSON.parse(toRotate), period);
		}
	}
	// INJECT CSS
	var css = document.createElement("style");
	css.type = "text/css";
	css.innerHTML = ".typewrite > .wrap { border-right: 0.08em solid transparent}";
	document.body.appendChild(css);
};
</script>

<section>
            <div class="container">
                <div class="row justify-content-center">

                    <div class="col-lg-9">

                        <div class="position-relative elements-block">

                            <div class="inner-title">
                                <div class="main-title title-left mb-0">Frequently Asked Questions
                                    <span class="line-left"></span>
                                </div>
                            </div>

                            <div id="accordion" class="accordion-style">
                                <div class="card">
                                    <div class="card-header" id="headingOne">
                                        <h5 class="mb-0">
                                            <button class="btn btn-link" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">How do I apply for a loan at Best Pick  Loan  (PTY) Ltd ?</button>
                                        </h5>
                                    </div>
                                    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-bs-parent="#accordion">
                                        <div class="card-body position-relative">
                                        You can apply for an Best Pick  Loan  (PTY) Ltd by clicking here or you can call us at loan@bestpickloans.co.za
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingTwo">
                                        <h5 class="mb-0">
                                            <button class="btn btn-link collapsed" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">How do I pay my monthly loan instalment?</button>
                                        </h5>
                                    </div>
                                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-bs-parent="#accordion">
                                        <div class="card-body position-relative">
                                        Your monthly loan instalment will be automatically debited from your bank account on a date you selected at time of application.
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingThree">
                                        <h5 class="mb-0">
                                            <button class="btn btn-link collapsed" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">Can I apply and be offered a loan if I have a Bad Credit Profile?</button>
                                        </h5>
                                    </div>
                                    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-bs-parent="#accordion">
                                        <div class="card-body position-relative">
                                        Whether you are Blacklisted,Debt Review or your Credit Score is very low, you can apply for a loan. At Best Pick  Loan   Service Loan company, we help you removed blacklisted and increase credit score.
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingFour">
                                        <h5 class="mb-0">
                                            <button class="btn btn-link collapsed" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">Do I need to pay upfront fee before getting a Loan ?</button>
                                        </h5>
                                    </div>
                                    <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-bs-parent="#accordion">
                                        <div class="card-body position-relative">
                                        Best Pick  Loan  (PTY) Ltd do not charge client with good credit profile. However, you only make payment for upfront fee payment if your a having low credit score, blacklisted or Debt review. This fee is also refunded when you make payment on our last instalment.
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-header" id="headingFive">
                                        <h5 class="mb-0">
                                            <button class="btn btn-link collapsed" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">Can I apply for a loan outside South Africa?</button>
                                        </h5>
                                    </div>
                                    <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-bs-parent="#accordion">
                                        <div class="card-body position-relative">
                                        Best Pick  Loan  (PTY) Ltd  application process is online-based. Whether you reside in South Africaor any part of the world. Best Pick  Loan  (PTY) Ltd company accept clients from all part of the world. So long you have all valid required documents.
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="copy-element"><a class="copy-clipboard" data-clipboard-target="#section">Copy</a></div>
                           

                            <div id="copy-code" class="mfp-hide white-popup-block popup-copy">
                                <div class="copy-element"><a class="copy-clipboard" data-clipboard-target="#section">copy</a></div>
                                <pre id="section" class=" language-html"><code class=" language-html">
<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>accordion<span class="token punctuation">"</span></span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>accordion-style<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-header<span class="token punctuation">"</span></span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingOne<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>h5</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>mb-0<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>button</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>btn btn-link<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-toggle</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-target</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#collapseOne<span class="token punctuation">"</span></span> <span class="token attr-name">aria-expanded</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>true<span class="token punctuation">"</span></span> <span class="token attr-name">aria-controls</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseOne<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>How quick will my credit be subsidized?<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>button</span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>h5</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseOne<span class="token punctuation">"</span></span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse show<span class="token punctuation">"</span></span> <span class="token attr-name">aria-labelledby</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingOne<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-parent</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#accordion<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-body position-relative<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised.
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-header<span class="token punctuation">"</span></span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingTwo<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>h5</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>mb-0<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>button</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>btn btn-link collapsed<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-toggle</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-target</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#collapseTwo<span class="token punctuation">"</span></span> <span class="token attr-name">aria-expanded</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>false<span class="token punctuation">"</span></span> <span class="token attr-name">aria-controls</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseTwo<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>What is outsourced financial support?<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>button</span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>h5</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseTwo<span class="token punctuation">"</span></span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">aria-labelledby</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingTwo<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-parent</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#accordion<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-body position-relative<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-header<span class="token punctuation">"</span></span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingThree<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>h5</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>mb-0<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>button</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>btn btn-link collapsed<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-toggle</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-target</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#collapseThree<span class="token punctuation">"</span></span> <span class="token attr-name">aria-expanded</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>false<span class="token punctuation">"</span></span> <span class="token attr-name">aria-controls</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseThree<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>How long is an affirmed financing cost and credit offer substantial?<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>button</span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>h5</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseThree<span class="token punctuation">"</span></span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">aria-labelledby</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingThree<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-parent</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#accordion<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-body position-relative<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-header<span class="token punctuation">"</span></span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingFour<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>h5</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>mb-0<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>button</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>btn btn-link collapsed<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-toggle</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-target</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#collapseFour<span class="token punctuation">"</span></span> <span class="token attr-name">aria-expanded</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>false<span class="token punctuation">"</span></span> <span class="token attr-name">aria-controls</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseFour<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>What sorts of commercial enterprise financing do you offer?<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>button</span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>h5</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseFour<span class="token punctuation">"</span></span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">aria-labelledby</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingFour<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-parent</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#accordion<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-body position-relative<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-header<span class="token punctuation">"</span></span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingFive<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>h5</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>mb-0<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>button</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>btn btn-link collapsed<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-toggle</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-target</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#collapseFive<span class="token punctuation">"</span></span> <span class="token attr-name">aria-expanded</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>false<span class="token punctuation">"</span></span> <span class="token attr-name">aria-controls</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseFive<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>How might I roll out an improvement to my application?<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>button</span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>h5</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">id</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapseFive<span class="token punctuation">"</span></span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>collapse<span class="token punctuation">"</span></span> <span class="token attr-name">aria-labelledby</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>headingFive<span class="token punctuation">"</span></span> <span class="token attr-name">data-bs-parent</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>#accordion<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;</span>div</span> <span class="token attr-name">class</span><span class="token attr-value"><span class="token punctuation">=</span><span class="token punctuation">"</span>card-body position-relative<span class="token punctuation">"</span></span><span class="token punctuation">&gt;</span></span>
                All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, Making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable.
            <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
        <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
    <span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
<span class="token tag"><span class="token tag"><span class="token punctuation">&lt;/</span>div</span><span class="token punctuation">&gt;</span></span>
                    </code></pre>
                            </div>

                        </div>

                    </div>

                </div>
            </div>
        </section>



   <!-- Footer Start -->
   <div class="container-fluid footer py-5 wow fadeIn" data-wow-delay="0.2s" style="background: #151533;">
            <div class="container py-5">
                <div class="row g-5">
                    <div class="col-xl-9">
                        <div class="mb-5">
                            <div class="row g-4">
                                <div class="col-md-6 col-lg-6 col-xl-5">
                                    <div class="footer-item">
                                        <a href="index.php" class="p-0">
                                            <h3 class="text-white"><img src="./img/logo.png" /> </h3>
                                            <!-- <img src="img/logo.png" alt="Logo"> -->
                                        </a>
                                        <p class="text-white mb-4">Best Pick  Loan (Pty)is a nationwide brokerage with over years experience in the credit industry that helps clients all over South Africa to obtain Loans.</p>
                                        <div class="footer-btn d-flex">
                                            <a class="btn btn-md-square rounded-circle me-3" href="#"><i class="fab fa-facebook-f"></i></a>
                                            <a class="btn btn-md-square rounded-circle me-3" href="#"><i class="fab fa-twitter"></i></a>
                                            <a class="btn btn-md-square rounded-circle me-3" href="#"><i class="fab fa-instagram"></i></a>
                                            <a class="btn btn-md-square rounded-circle me-0" href="#"><i class="fab fa-linkedin-in"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-lg-6 col-xl-3">
                                    <div class="footer-item">
                                        <h4 class="text-white mb-4">Loan Offers</h4>
                                        <a href="./personal-loan.php"><i class="fas fa-angle-right me-2"></i> Personal Loans</a>
                                        <a href="./business-loan.php"><i class="fas fa-angle-right me-2"></i> Business Loans</a>
                                        <a href="./app.php?apply03"><i class="fas fa-angle-right me-2"></i> Cash Advance</a>
                                        <a href="./home-loan.php"><i class="fas fa-angle-right me-2"></i> Home Loan</a>
                                        <a href="./carloan.php"><i class="fas fa-angle-right me-2"></i> Auto Loan</a>
                                    </div>
                                </div>
                                <div class="col-md-6 col-lg-6 col-xl-3">
                                    <div class="footer-item">
                                        <h4 class="text-white mb-4">Useful Links</h4>
                                        <a href="./about.php"><i class="fas fa-angle-right me-2"></i> About Us</a>
                                        <a href="./personal-loan.php"><i class="fas fa-angle-right me-2"></i> Cash Advance</a>
                                        <a href="./business-loan.php"><i class="fas fa-angle-right me-2"></i> Apply for loan</a>
                                        <a href="./app.php?apply03"><i class="fas fa-angle-right me-2"></i> Cash Advance</a>
                                        <a href="./home-loan.php"><i class="fas fa-angle-right me-2"></i> Home Loan</a>
                                        <a href="./carloan.php"><i class="fas fa-angle-right me-2"></i> Auto Loan</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="pt-5" style="border-top: 1px solid rgba(255, 255, 255, 0.08);">
                            <div class="row g-0">
                                <div class="col-12">
                                    <div class="row g-4">
                                        <div class="col-lg-6 col-xl-4">
                                            <div class="d-flex">
                                                <div class="btn-xl-square bg-primary text-white rounded p-4 me-4">
                                                    <i class="fas fa-map-marker-alt fa-2x"></i>
                                                </div>
                                                <div>
                                                   <!-- <h4 class="text-white">Address</h4> -->
                                                    <p class="mb-0 text-white">49 Avenue Street Louwsburg 3150</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-xl-4">
                                            <div class="d-flex">
                                                <div class="btn-xl-square bg-primary text-white rounded p-4 me-4">
                                                    <i class="fas fa-envelope fa-2x"></i>
                                                </div>
                                                <div>
                                                    <h4 class="text-white">Mail Us</h4>
                                                    <p class="mb-0 text-white">loan@bestpickloans.co.za</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-xl-4">
                                            <div class="d-flex">
                                                <div class="btn-xl-square bg-primary text-white rounded p-4 me-4">
                                                    <i class="fa fa-phone-alt fa-2x"></i>
                                                </div>
                                                <div>
                                                    <h4 class="text-white">Telephone</h4>
                                                    <p class="mb-0  text-white "> Whatsapp: 0736505209, 0719443402</p>
                                                    <p class="mb-0 text-white"> Tel: 0736505209, 0719443402 <br>+27145470012</p>
                                                   
                                                   
                                                   


                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-xl-3">
                        <div class="footer-item">
                            <h4 class="text-white mb-4">Newsletter</h4>
                            <p class="text-white mb-3 ">We work all days a week, Please contact us for any inquiry.</p>
                            <div class="">
                <div class="">
                    <h5>Open Hours</h5>
               
                    <ul>
                    <li class="nav-link text-white">We work all days a week, Please contact us for any inquiry.</li>
                        <li class="nav-link text-white">Monday - Friday: 8:00 am - 5:00 pm</li>
                        <li class="nav-link text-white">Saturday: 8:00 am - 1:00 pm</li>
                        <li class="nav-link text-white">Closed</li>
                    </ul>
                </div>
            </div>
                           
                          
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer End -->



 <!-- custom scripts -->
 <script src="https://loan.websitelayout.net/js/main.js"></script>
<!-- jquery -->
<script src="https://loan.websitelayout.net/js/core.min.js"></script>

 <!-- jQuery -->
 <script src="https://loan.websitelayout.net/js/jquery.min.js"></script>


 
    <!-- form plugins js -->
    <script src="https://loan.websitelayout.net/quform/js/plugins.js"></script>

    <!-- form scripts js -->
    <script src="https://loan.websitelayout.net/quform/js/scripts.js"></script>
 
    


<!-- popper js -->
<script src="js/popper.min.js"></script>
<!-- <script src="js/jquery.min.js"></script>-->

<!-- bootstrap -->
<script src="js/bootstrap.mtin.js"></script>

    
<!-- Back to Top -->
<a href="#" class="btn btn-primary btn-lg-square rounded-circle back-to-top"><i class="fa fa-arrow-up"></i></a>   

        
<!-- JavaScript Libraries -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="./style2/lib/wow/wow.min.js"></script>
<script src="./style2/lib/easing/easing.min.js"></script>
<script src="./style2/lib/waypoints/waypoints.min.js"></script>
<script src="./style2/lib/counterup/counterup.min.js"></script>
<script src="./style2/lib/lightbox/js/lightbox.min.js"></script>
<script src="./style2/lib/owlcarousel/owl.carousel.min.js"></script>


<!-- Template Javascript -->
<script src="./style2/js/main.js"></script>    <!-- Footer Section End -->

    <!-- Search Begin -->
    <div class="search-model">
        <div class="h-100 d-flex align-items-center justify-content-center">
            <div class="search-close-switch">+</div>
            <form class="search-model-form">
                <input type="text" id="search-input" placeholder="Search here.....">
            </form>
        </div>
    </div>
    <!-- Search End -->

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.nicescroll.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
</body>

</html>