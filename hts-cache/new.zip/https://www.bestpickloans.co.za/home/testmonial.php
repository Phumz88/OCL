<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Best Pick  Loan  (PTY) Ltd ">
    <meta name="keywords" content="Best Pick  Loan  (PTY) Ltd , CCM, About Best Pick  Loan  , ">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Best Pick  Loan  (PTY) Ltd | About us</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700;900&display=swap" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<body>
    <!-- Page Preloder -->
    <link rel="stylesheet" href="./plugins.css" type="text/css">
<link rel="stylesheet" href="./pluinstyle.css" type="text/css">
 <!-- theme core css -->
 

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@icon/themify-icons@1.0.1-alpha.3/themify-icons.min.css">

     <!-- Libraries Stylesheet -->
     <link rel="stylesheet" href="./style2/lib/animate/animate.min.css"/>
        <link href="./style2/lib/lightbox/css/lightbox.min.css" rel="stylesheet">
        <link href="./style2/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

        <!-- Customized Bootstrap Stylesheet -->
        <link href="./style2/css/bootstrap.min.css" rel="stylesheet">
        <!-- Template Stylesheet -->
        <link href="./style2/css/style.css" rel="stylesheet">

        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

        <!-- Icon Font Stylesheet -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    
    <!--Animation--> 
    <link href="./css/aos.css" rel="stylesheet">
    <!--Animation Script--> 
<script src="./js/aos.js"></script>
        <script>
        AOS.init();
        </script>


<!--
<div id="preloder">
    <div class="loader"></div>
</div>-->

  <!-- Spinner Start -->
  <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

<style>
.bg-gradient-pink{
    background: #CF327B;
 
}
</style>

<!-- Offcanvas Menu Begin -->
<div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel"  style="z-index:111111111 !important;">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasRightLabel"> <h1 class="text-primary mb-0 ms-2"><small> <img src="./img/logo.png" alt="" srcset=""> </small></h1></h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
  <a href="./app.php?a23c66w8-329b-4e67-9169-c5f5899dee4f" class="btn btn-primary rounded-pill py-2 px-4 ms-3 flex-shrink-0 mb-3"> Get Loan <i class="fa fa-arrow-right"></i> </a>
<ul class="list-style1 list-unstyled mb-0 ps-0">
    <li><a href="./index.php">Home  <i class="ti ti-arrow-right"></i></li>
    <li><a href="./personal-loan.php">Personal Loan <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./business-loan.php">Business Loan <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./home-loan.php">Home Loan <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./education-loan.php">Education Loan <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./carloan.php">Auto Loan <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./insurance.php">Insurance <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./about.php">About us  <i class="ti ti-arrow-right"></i></a></li>
    <li><a href="./testmonial.php">Testimonials  <i class="ti ti-arrow-right"></i></a></li>
     <li><a href="./contact.php">Contact us  <i class="ti ti-arrow-right"></i></a></li>
  
   
</ul>

                                    
  </div>
</div>
        <!-- Topbar Start -->
        <div class="container-fluid topbar px-0 px-lg-4 bg-light py-2 d-block">
            <div class="container">
                <div class="row gx-0 align-items-center">
                    <div class="col-lg-8 text-center text-lg-start mb-lg-0">
                        <div class="d-flex">
                            <div class="border-end border-dark pe-3">
                                <a href="#" class="text-muted small"><i class="bi bi-whatsapp text-primary me-2"></i> 0736505209, +27145470012</a>
                            </div>
                            <div class="ps-3">
                                <a href="mailto:loan@bestpickloans.co.za" class="text-muted small"><i class="fas fa-envelope text-primary me-2"></i>loan@bestpickloans.co.za</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 text-center text-lg-end">
                        <div class="d-flex justify-content-end">
                            <div class="d-flex border-end border-primary pe-3 d-none d-lg-block">
                                <a class="btn p-0 text-dark me-3" href="#"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn p-0 text-dark me-3" href="#"><i class="fab fa-twitter"></i></a>
                                <a class="btn p-0 text-dark me-3" href="#"><i class="fab fa-instagram"></i></a>
                                <a class="btn p-0 text-dark me-0" href="#"><i class="fab fa-linkedin-in"></i></a>
                            </div>
                            <div class="dropdown ms-3">
                                <a href="#" class="dropdown-toggle text-dark" data-bs-toggle="dropdown"><small><i class="fas fa-globe-europe text-primary me-2"></i> English</small></a>
                                <div class="dropdown-menu rounded">
                                    <a href="#" class="dropdown-item">English</a>
                                    <a href="#" class="dropdown-item">Bangla</a>
                                    <a href="#" class="dropdown-item">French</a>
                                    <a href="#" class="dropdown-item">Spanish</a>
                                    <a href="#" class="dropdown-item">Arabic</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Topbar End -->


      <!-- Navbar & Hero Start -->
     
<div class="container-fluid nav-bar px-0 px-lg-4 py-lg-0">
            <div class="">
                <nav class="navbar navbar-expand-lg navbar-light"> 
                    <a href="#" class="navbar-brand p-0">
                        <h3 class="text-dark mb-0 ms-2"><i class="fab fas-seadling me-2"></i><small><img src="./img/logo.png" alt="" srcset="" class="w-100"></small></h3>
                        <!-- <img src="img/logo.png" alt="Logo"> -->
                    </a>
                    <button class="navbar-toggler me-2" type="button" data-bs-toggle="offcanvas" href="#offcanvasRight" role="button" aria-controls="offcanvasRight">
                        <span class="fa fa-bars"></span>
                    </button>
                    <div class="navbar-collapse collapse" id="navbarCollapse" style="">
                        <div class="navbar-nav mx-0 mx-lg-auto">
                            <a href="./index.php" class="nav-item nav-link active">Home</a>
                            <a href="./about.php" class="nav-item nav-link">About</a>
                         
                        
                            <div class="nav-item dropdown">
                                <a href="#" class="nav-link" data-bs-toggle="dropdown">
                                    <span class="dropdown-toggle">Loan Services</span>
                                </a>
                                <div class="dropdown-menu">
                                    <a href="./personal-loan.php" class="dropdown-item">Personal Loans</a>
                                    <a href="./business-loan.php" class="dropdown-item">Business Loans</a>
                                    <a href="./home-loan.php" class="dropdown-item">Home Loan</a>
                                    <a href="./education-loan.php" class="dropdown-item">Education Loan</a>
                                    <a href="./carloan.php" class="dropdown-item">Auto Loan</a>
                                </div>
                            </div>
                            <a href="./insurance.php" class="nav-item nav-link">Insurance</a>
                            <a href="./testmonial.php" class="nav-item nav-link">Testimonial</a>
                            <a href="./contact.php" class="nav-item nav-link">Contact us</a>
                            <a href="./app.php?a23c66w8-329b-4e67-9169-c5f5899dee4f" class="btn btn-primary rounded-pill py-2 px-4 ms-3 flex-shrink-0"> Get Loan <i class="fa fa-arrow-right"></i> </a>
                           
                        </div>
                    </div>
                    <div class="d-none d-xl-flex flex-shrink-0 ps-4">
                        <a href="#" class="btn btn-primary btn-lg-square rounded-circle position-relative wow tada" data-wow-delay=".9s" style="visibility: visible; animation-delay: 0.9s; animation-name: tada;">
                            <i class="bi bi-whatsapp fa-2x"></i>
                            <div class="position-absolute" style="top: 7px; right: 12px;">
                               <!-- <span><i class="fa fa-comment-dots text-secondary"></i></span>-->
                            </div>
                        </a>
                        <div class="d-flex flex-column ms-3">
                            <span class="text-primary fw-bolder">Whatsapp support</span>
                            <a href="tel: 0736505209"><span class="text-dark"> 0736505209</span></a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>

     
        <!-- Navbar & Hero End -->

        <!-- Modal Search Start -->
        <div class="modal fade" id="searchModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content rounded-0">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Search by keyword</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body d-flex align-items-center bg-primary">
                        <div class="input-group w-75 mx-auto d-flex">
                            <input type="search" class="form-control p-3" placeholder="keywords" aria-describedby="search-icon-1">
                            <span id="search-icon-1" class="btn bg-light border nput-group-text p-3"><i class="fa fa-search"></i></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal Search End -->

    <!-- Header Section End -->

    <!-- Breadcrumb Section Begin -->
    <div class="breadcrumb-option set-bg" data-setbg="img/breadcrumb/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb__text">
                        <h2>Clients Testimonial</h2>
                        <div class="breadcrumb__links">
                            <a href="./index.php">Home</a>
                            <span>Testimonial</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Section End -->
<section class="container-fluid py-5">
    <div class="container">







    </div>

</section>
  


<!--testimony-->

<style>
      
      </style>
      <div class="container d-flex justify-content-center mt-100 mb-100">
    <div class="row">
  
    
Database connection not established.